#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AqueGenNinjaBotStrategy : Strategy
    {
        //#region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
		

		private double _numLow = 0;
		private double _numHigh = 0;
		
		private double _price = 0;

		private int _period = 20;
		private bool _isLongTrend = true;
		private bool _isLongTrendPreLast = true;
		private bool _isLongTrendStartOrder;
		
		
		private int _waitBarsAfterChangeTrend = 5;
		private int _waitBarsAfterCloseOrder = 10;
      	private bool _isActivateTimeOut = false;
		
      	private int indexBarAfterCloseOrder = 0;
		private int indexBarAfterChangeTrend = 0;
      
		
        private int 	strength 		= 5; 		// Default setting for Strength


		private bool isOrderPresent = false;
		
		private double startOrderPrice = 0;
		
		private string	atmStrategyId		= string.Empty;
		private string	orderId				= string.Empty;
		
		private string openedOrderId;
		
		private bool isFoundTrend = false;
		
      	private int barIndex = 0;
      	private int singleBarIndex = 0;
      
		private int		fast	= 5;
		private int		slow	= 30;

		
		//zigzag
		private double			currentZigZagHigh	= 0;
		private double			currentZigZagLow	= 0;
		private DeviationType	deviationType		= DeviationType.Points;
		private double			deviationValue		= 0.5;
		private DataSeries		zigZagHighZigZags; 
		private DataSeries		zigZagLowZigZags; 
		private DataSeries		zigZagHighSeries; 
		private DataSeries		zigZagLowSeries; 
		private int				lastSwingIdx		= -1;
		private double			lastSwingPrice		= 0.0;
		private int				trendDir			= 0; // 1 = trend up, -1 = trend down, init = 0
		private bool			useHighLow			= false;
		
		
		private bool isTrendOnPeriodDown;
		private double firstLevelPrice = 0;
		private double secondLevelPrice = 0;
		private double thirdLevelPrice = 0;
		
		private int highBar = 0;
		private int lowBar = 0;
		private int highBarPeriod = 0;
		private int lowBarPeriod = 0;
		
		private int periodOfCalculate = 0;

		
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {

            CalculateOnBarClose = true;
			Add(WMA(Fast));
            Add(WMA(Slow));	
			WMA(Fast).Plots[0].Pen.Color = Color.Green;
			WMA(Slow).Plots[0].Pen.Color = Color.Red;
			
			
			
			//zigzag
			zigZagHighSeries	= new DataSeries(this, MaximumBarsLookBack.Infinite); 
			zigZagHighZigZags	= new DataSeries(this, MaximumBarsLookBack.Infinite); 
			zigZagLowSeries		= new DataSeries(this, MaximumBarsLookBack.Infinite); 
			zigZagLowZigZags	= new DataSeries(this, MaximumBarsLookBack.Infinite); 

			//DisplayInDataBox	= false;
            //Overlay				= true;
			//PaintPriceMarkers	= false;
			

        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
		
        protected override void OnBarUpdate()
        {	

			barIndex++;
			Print("------------------");
			
			
			ZigZagUpdateOnBar();
			Print("lowBar -> " + lowBar);
			Print("highBar -> " + highBar);
			
			/*
          	//CalculateOnBarClose = false;
			double fastPrice = GetWmaPrice(Fast);
            double slowPrice = GetWmaPrice(Slow);
          	//CalculateOnBarClose = true;
          
			if(fastPrice > -1 && slowPrice > -1){
				if(fastPrice > slowPrice){
					_isLongTrendPreLast = IsLongTrend;
					IsLongTrend = true;
					isFoundTrend = true;
					Print("_isLongTrendPreLast -> " + _isLongTrendPreLast);
					Print("IsLongTrend -> " + IsLongTrend);
				}
				else{
					_isLongTrendPreLast = IsLongTrend;
					IsLongTrend = false;
					isFoundTrend = true;
					Print("_isLongTrendPreLast -> " + _isLongTrendPreLast);
					Print("IsLongTrend -> " + IsLongTrend);
				}
			}
          	*/
			Print("Trend is -> " + IsLongTrend);
			Print("Now Bar is -> " + CurrentBar);
			
			int startBar = 0;
			int endBar = 0;
			
			
			if(highBarPeriod > lowBarPeriod){
				periodOfCalculate = highBarPeriod - lowBarPeriod;
				isTrendOnPeriodDown = false;
				startBar = lowBarPeriod;
				endBar = highBarPeriod;
			}
			else{
				periodOfCalculate = lowBarPeriod - highBarPeriod;
				isTrendOnPeriodDown = true;
				startBar = highBarPeriod;
				endBar = lowBarPeriod;
			}
			Print("StartPeriod -> " + startBar);
			Print("EndPeriod -> " + endBar);
			if(isTrendOnPeriodDown){
				firstLevelPrice = GetLowOrHigh(true, startBar, startBar + (periodOfCalculate / 3));
				secondLevelPrice = GetLowOrHigh(true, startBar + (periodOfCalculate/3), endBar - (periodOfCalculate/3));
				thirdLevelPrice = GetLowOrHigh(false, endBar - (periodOfCalculate/3), endBar);
			}
			else{
				firstLevelPrice = GetLowOrHigh(false, startBar, startBar + (periodOfCalculate / 3));
				secondLevelPrice = GetLowOrHigh(false, startBar + periodOfCalculate/3, endBar - (periodOfCalculate/3));
				thirdLevelPrice = GetLowOrHigh(true, endBar - (periodOfCalculate/3), endBar);
			}
			
			//SetLowAndHigh();
			
			Print("firstLevelPrice -> " + firstLevelPrice);
			Print("secondLevelPrice -> " + secondLevelPrice);
			Print("thirdLevelPrice -> " + thirdLevelPrice);
			
			
			
			
			
        }
		
		private double GetWmaPrice(int period){
		
			if (CurrentBar == 0){}
				//Value.Set(Input[0]);
			else
			{
				int		back	= Math.Min(period - 1, CurrentBar);
				double	val		= 0;
				int		weight	= 0;
				for (int idx = back; idx >=0; idx--)
				{
					val		+= (idx + 1) * Input[back - idx];
					weight	+= (idx + 1);
				}
				Print(period + " <--> " + (val / weight));
				return (val / weight);
			}
			Print(period + " <--> -1");
			return -1;
		}
		
		private double GetLowOrHigh(bool isFoundLowPriceOnBar, int startBar, int endBar){
			/*NumLow = Low[Period];
			NumHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(NumLow < Low[bar]){
					NumLow = Low[bar];
				}
				if(NumHigh > High[bar]){
					NumHigh = High[bar];
				}
			}*/
			double low = Low[CurrentBar - startBar];
			double high = High[CurrentBar - startBar];
			int start = CurrentBar - startBar;
			int end = CurrentBar - endBar;
			Print("Start -> " + start);
			Print("End -> " + end);
			for(;start > end; start--){
				if(isFoundLowPriceOnBar){
					if(low < Low[start]){
						low = Low[start];
						//Print("low < Low[start] -> " + low);
					}
				}
				else{
					if(high > High[start]){
						high = High[start];
						//Print("high > High[start] -> " + high);
					}
				}
			}
			
			if(isFoundLowPriceOnBar)
				return low;
			else
				return high;
		}
		
		
		
		
		private void ZigZagUpdateOnBar(){
		if (CurrentBar < 2) // need 3 bars to calculate Low/High
			{
				zigZagHighSeries.Set(0);
				zigZagHighZigZags.Set(0);
				zigZagLowSeries.Set(0);
				zigZagLowZigZags.Set(0);
				return;
			}

			// Initialization
			if (lastSwingPrice == 0.0)
				lastSwingPrice = Input[0];

			IDataSeries highSeries	= High;
			IDataSeries lowSeries	= Low;

			if (!useHighLow)
			{
				highSeries	= Input;
				lowSeries	= Input;
			}

			// Calculation always for 1-bar ago !

			double tickSize = Bars.Instrument.MasterInstrument.TickSize;
			bool isSwingHigh	= highSeries[1] >= highSeries[0] - double.Epsilon 
								&& highSeries[1] >= highSeries[2] - double.Epsilon;
			bool isSwingLow		= lowSeries[1] <= lowSeries[0] + double.Epsilon 
								&& lowSeries[1] <= lowSeries[2] + double.Epsilon;  
			bool isOverHighDeviation	= (deviationType == DeviationType.Percent && IsPriceGreater(highSeries[1], (lastSwingPrice * (1.0 + deviationValue * 0.01))))
										|| (deviationType == DeviationType.Points && IsPriceGreater(highSeries[1], lastSwingPrice + deviationValue));
			bool isOverLowDeviation		= (deviationType == DeviationType.Percent && IsPriceGreater(lastSwingPrice * (1.0 - deviationValue * 0.01), lowSeries[1]))
										|| (deviationType == DeviationType.Points && IsPriceGreater(lastSwingPrice - deviationValue, lowSeries[1]));

			Print("--------------");
			
			double	saveValue	= 0.0;
			bool	addHigh		= false; 
			bool	addLow		= false; 
			bool	updateHigh	= false; 
			bool	updateLow	= false; 

			zigZagHighZigZags.Set(0);
			zigZagLowZigZags.Set(0);

			if (!isSwingHigh && !isSwingLow)
			{
				zigZagHighSeries.Set(currentZigZagHigh);
				zigZagLowSeries.Set(currentZigZagLow);
				return;
			}
			
			if (trendDir <= 0 && isSwingHigh && isOverHighDeviation)
			{	
				saveValue	= highSeries[1];
				addHigh		= true;
				Print("Add Low -> ");
				trendDir	= 1;
			}	
			else if (trendDir >= 0 && isSwingLow && isOverLowDeviation)
			{	
				saveValue	= lowSeries[1];
				addLow		= true;
				Print("Add Low -> ");
				trendDir	= -1;
			}	
			else if (trendDir == 1 && isSwingHigh && IsPriceGreater(highSeries[1], lastSwingPrice)) 
			{
				saveValue	= highSeries[1];
				updateHigh	= true;
			}
			else if (trendDir == -1 && isSwingLow && IsPriceGreater(lastSwingPrice, lowSeries[1])) 
			{
				saveValue	= lowSeries[1];
				updateLow	= true;
			}

			if (addHigh || addLow || updateHigh || updateLow)
			{
				if (updateHigh && lastSwingIdx >= 0)
				{
					zigZagHighZigZags.Set(CurrentBar - lastSwingIdx, 0);
					//highBar = CurrentBar;
					//Value.Reset(CurrentBar - lastSwingIdx);
				}
				else if (updateLow && lastSwingIdx >= 0)
				{
					zigZagLowZigZags.Set(CurrentBar - lastSwingIdx, 0);
					//lowBar = CurrentBar;
					//Value.Reset(CurrentBar - lastSwingIdx);
				}

				if (addHigh || updateHigh)
				{
					zigZagHighZigZags.Set(1, saveValue);
					zigZagHighZigZags.Set(0, 0);

					currentZigZagHigh = saveValue;
					zigZagHighSeries.Set(1, currentZigZagHigh);
					//Value.Set(1, currentZigZagHigh);
					
					_isLongTrendPreLast = IsLongTrend;
					IsLongTrend = true;
					isFoundTrend = true;
					
					if(addHigh && !updateHigh){
						lowBarPeriod = lowBar;
						highBar = CurrentBar;
						Print("lowBarPeriod -> " + lowBarPeriod);
						//Print("Upper trend -> " + currentZigZagHigh);
					}
					
					
				}
				else if (addLow || updateLow) 
				{
					zigZagLowZigZags.Set(1, saveValue);
					zigZagLowZigZags.Set(0, 0);

					currentZigZagLow = saveValue;
					zigZagLowSeries.Set(1, currentZigZagLow);
					//Value.Set(1, currentZigZagLow);
					
					_isLongTrendPreLast = IsLongTrend;
					IsLongTrend = false;
					isFoundTrend = true;
					
					if(addLow && !updateLow){
						highBarPeriod = highBar;
						lowBar = CurrentBar;
						Print("highBarPeriod ->" + highBarPeriod);
						//Print("Lower trend ->" + currentZigZagLow);
					}
					
					
				}

				lastSwingIdx	= CurrentBar - 1;
				lastSwingPrice	= saveValue;
			}

			zigZagHighSeries.Set(currentZigZagHigh);
			zigZagLowSeries.Set(currentZigZagLow);
			
			NumLow = currentZigZagLow;
			NumHigh = currentZigZagHigh;
		
		
		}
		
		

		private bool IsPriceGreater(double a, double b)
		{
			if (a > b && a - b > TickSize / 2)
				return true; 
			else 
				return false;
		}
		
		
		
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
				Price = e.Price;
								
				BuyOrSell(Price);
			}
		}
		

		private bool IsActivateTimeOutAfterCloseOrder(double startOrderPrice, double price, bool isLongTrend, bool isLongTrendStartOrder){
			if(isLongTrend && isLongTrendStartOrder){
				if(price < startOrderPrice)
					return true;
				else
					return false;
			}
			else
			if(!isLongTrend && !isLongTrendStartOrder){
				if(price > startOrderPrice)
					return true;
				else
					return false;
			}
			return false;
		}
		
		private bool IsActivateTimeOutAfterChangeTrend(bool isLongTrend, bool isLongTrendPreLast){
			return isLongTrend != isLongTrendPreLast;
		}
			
		
		private void BuyOrSell(double price){

			return;
			if (orderId.Length == 0 && atmStrategyId.Length == 0)
			{

				if(IsActivateTimeOut == true /*&& isOrderPresent == true*/ && IsActivateTimeOutAfterChangeTrend(IsLongTrend, _isLongTrendPreLast)){
					indexBarAfterChangeTrend = barIndex + _waitBarsAfterChangeTrend;
					//isOrderPresent = false;
				}
				
				if(IsActivateTimeOut == true /*&& GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat */
					&& isOrderPresent == true && IsActivateTimeOutAfterCloseOrder(startOrderPrice, price, IsLongTrend, _isLongTrendStartOrder)){
					
					indexBarAfterCloseOrder = barIndex + _waitBarsAfterCloseOrder;
					isOrderPresent = false;
				}
				
					//Print("Now Bar is -> " + barIndex);
					//Print("TimeOut Change Trend New Next Order Time is -> " + indexBarAfterChangeTrend);
					//Print("TimeOut Close Order New Next Order Time is -> " + indexBarAfterCloseOrder);
					
				if(/*GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat &&*/ isFoundTrend 
					&& barIndex > indexBarAfterCloseOrder && barIndex > indexBarAfterChangeTrend){
					
					if(isTrendOnPeriodDown){
						if(price == thirdLevelPrice){
							atmStrategyId = GetAtmStrategyUniqueId();
							orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Buy, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							Print("OrderAction.Buy");
							_isLongTrendStartOrder = IsLongTrend;
							startOrderPrice = price;
							openedOrderId = orderId;
							isOrderPresent = true;
						} else
						if(price == firstLevelPrice || price == secondLevelPrice){// upper then green line	
							atmStrategyId = GetAtmStrategyUniqueId();
							orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Sell, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							Print("OrderAction.Sell");
							_isLongTrendStartOrder = IsLongTrend;
							startOrderPrice = price;
							openedOrderId = orderId;
							isOrderPresent = true;
						}
					}
					else{
						if(price == firstLevelPrice || price == secondLevelPrice){
							atmStrategyId = GetAtmStrategyUniqueId();
							orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Buy, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							Print("OrderAction.Buy");
							_isLongTrendStartOrder = IsLongTrend;
							startOrderPrice = price;
							openedOrderId = orderId;
							isOrderPresent = true;
						} else
						if(price == thirdLevelPrice){// upper then green line	
							atmStrategyId = GetAtmStrategyUniqueId();
							orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Sell, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							Print("OrderAction.Sell");
							_isLongTrendStartOrder = IsLongTrend;
							startOrderPrice = price;
							openedOrderId = orderId;
							isOrderPresent = true;
						}
					}
					
					
				}
			
			}
			
			if (orderId.Length > 0)
			{
				string[] status = GetAtmStrategyEntryOrderStatus(orderId);
                
				// If the status call can't find the order specified, the return array length will be zero otherwise it will hold elements
				if (status.GetLength(0) > 0)
				{
					// Print out some information about the order to the output window
					Print("The entry order average fill price is: " + status[0]);
					Print("The entry order filled amount is: " + status[1]);
					Print("The entry order order state is: " + status[2]);

					// If the order state is terminal, reset the order id value
					if (status[2] == "Filled" || status[2] == "Cancelled" || status[2] == "Rejected")
						orderId = string.Empty;
				}
			} // If the strategy has terminated reset the strategy id
			else if (atmStrategyId.Length > 0 && GetAtmStrategyMarketPosition(atmStrategyId) == Cbi.MarketPosition.Flat)
				atmStrategyId = string.Empty;
				
		}
		
		
        #region Properties	
		
		[Description("Period for fast MA")]
		[GridCategory("Parameters")]
		public int Fast
		{
			get { return fast; }
			set { fast = Math.Max(1, value); }
		}

		[Description("Period for slow MA")]
		[GridCategory("Parameters")]
		public int Slow
		{
			get { return slow; }
			set { slow = Math.Max(1, value); }
		}

		
		
		[Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set { _period = Math.Max(1, value); }
        }
	
		
		
 		[Description("Number of bars to wait after each trade")]
        [Category("Parameters")]
        public int WaitBarsAfterCloseOrder 
        {
           get{return _waitBarsAfterCloseOrder;}
           set{_waitBarsAfterCloseOrder = value;}
        }
		
		[Description("Number of bars to wait after each trade")]
        [Category("Parameters")]
        public int WaitBarsAfterChangeTrend 
        {
           get{return _waitBarsAfterChangeTrend;}
           set{_waitBarsAfterChangeTrend = value;}
        }
		
      
        [Description("Is wait after each trade")]
        [Category("Parameters")]
        public bool IsActivateTimeOut 
        {
          get{return _isActivateTimeOut;}
          set{_isActivateTimeOut = value;}
        }
       
		[Description("Deviation in percent or points regarding on the deviation type")]
        [GridCategory("Parameters")]
		[Gui.Design.DisplayName("Deviation value")]
        public double DeviationValue
        {
            get { return deviationValue; }
            set { deviationValue = Math.Max(0.0, value); }
        }

        [Description("Type of the deviation value")]
        [GridCategory("Parameters")]
		[Gui.Design.DisplayName("Deviation type")]
        public DeviationType DeviationType
        {
            get { return deviationType; }
            set { deviationType = value; }
        }

        [Description("If true, high and low instead of selected price type is used to plot indicator.")]
        [GridCategory("Parameters")]
		[Gui.Design.DisplayName("Use high and low")]
		[RefreshProperties(RefreshProperties.All)]
        public bool UseHighLow
        {
            get { return useHighLow; }
            set { useHighLow = value; }
        }
		
		
        private bool IsLongTrend
        {
            get { return _isLongTrend; }
            set { _isLongTrend = value; }
        }
		
		private double NumLow {
			get{return _numLow;} 
			set{_numLow = value;}
		}
			
		private double NumHigh {
			get{return _numHigh;} 
			set{_numHigh = value;}
		}
		
		private double Price {
			get{return _price;} 
			set{_price = value;}
		}
		
		
        #endregion
    }
}
