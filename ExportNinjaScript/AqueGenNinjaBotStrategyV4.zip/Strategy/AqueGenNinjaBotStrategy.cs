#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AqueGenNinjaBotStrategy : Strategy
    {
        //#region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
		private bool _isOrderPresent = false;
		
		private double _numLow = 0;
		private double _numHigh = 0;
		private int _period = 20;
		private int _newPeriod = 0;
		
		private int _timeOutBetweenOrder = 0;
		
		private double _price = 0;
		private double _closeLastPrice = 0;
		
		private bool _isLongBar = false;

		private double _stopLossTicks = 3.0;
		private double _changeStopLossAfterTicks = 5.0;
		
		private double _nextStopLossPriceLong = 0.0;
		private double _lastStopLossPriceLong = 0.0;

		private double _nextStopLossPriceShort = 0.0;
		private double _lastStopLossPriceShort = 0.0;

        // User defined variables (add any user defined variables below)
        //#endregion

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			
			//SetProfitTarget("", CalculationMode.Ticks, _stopLossTicks + 5);
            //SetTrailStop("", CalculationMode.Ticks, _stopLossTicks, false);
			SetStopLoss(CalculationMode.Ticks, _stopLossTicks);
            CalculateOnBarClose = true;
			
			

        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {	
			
		
			/*if (ToTime(Time[0]) >= ToTime(1, 0, 0))
            {
                DrawDiamond("My diamond" + CurrentBar, false, 0, High[0], Color.Red);
                EnterShort(1, "SELL");
            }
			*/
			SetLowAndHigh();
			
        }
		
		private void SetLowAndHigh(){
			_numLow = Low[Period];
			_numHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(_numLow < Low[bar]){
					_numLow = Low[bar];
				}
				if(_numHigh > High[bar]){
					_numHigh = High[bar];
				}
			}
		}
		
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			
			// Print some data to the Output window
			if (e.MarketDataType == MarketDataType.Last) {
				_price = e.Price;
			}
			
			ChangeOnPriceUpdate(_price);
			
			/*	if (_isOrderLong == false && _isOrderPresent)
				{
					if(_price < NextChangeStopLossPrice(_price)
							&& Position.MarketPosition == MarketPosition.Short){
						SetStopLoss(CalculationMode.Price, _price + _changeStopLossAfterTicks/10);
					}
				}
				else if(_isOrderLong == true && _isOrderPresent){
					if(_price > NextChangeStopLossPrice(_price)
							&& Position.MarketPosition == MarketPosition.Long){
						SetStopLoss(CalculationMode.Price, _price - _changeStopLossAfterTicks/10);
					}
				}
				*/
	
			
		}
		
		
		private void ChangeOnPriceUpdate(double price){

			if(_price >= Close[0])
				_isLongBar = true;
			else
				_isLongBar = false;
			
			BuyOrSell(price, _isLongBar);
		}
		

		
		
		private void BuyOrSell(double price, bool isLongBar){
			Print("BuyOrSell");
			if(!isLongBar){
				if(price < _numHigh){
					EnterLong(1,"");
					_isOrderPresent = true;
					Print("EnterLong -> " + price);
				}
				Print("BuyOrSell -> Long");
			}
			else{
				if(price > _numLow){
					EnterShort(1,"");
					_isOrderPresent = true;
					Print("EnterShort -> " + price);
				}
				
			}
			
		}
		

		
        #region Properties		
		[Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set { _period = Math.Max(1, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public int TimeOutBetweenOrder
        {
            get { return _timeOutBetweenOrder; }
            set { _timeOutBetweenOrder = Math.Max(1, value); }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public double StopLossTicks
        {
            get { return _stopLossTicks; }
            set { _stopLossTicks = Math.Max(0, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public double ChangeStopLossAfterTicks
        {
            get { return _changeStopLossAfterTicks; }
            set { _changeStopLossAfterTicks = Math.Max(0, value); }
        }
		
        #endregion
    }
}
