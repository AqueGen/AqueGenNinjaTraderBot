#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AqueGenNinjaBotStrategy : Strategy
    {
        //#region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
		
		private double _numLow = 0;
		private double _numHigh = 0;
		
		private double _price = 0.0;
		
	
		

		private int _period = 20;
		private bool _isLongTrend = true;
		
		

		
		
		
		
		private bool	alertOnBreak = true;
        private int 	strength 		= 5; 		// Default setting for Strength
		private bool	showHistory		= true;		//Show trend line history
    	private Color 	downTrendColor 	= Color.Red;
		private Color 	upTrendColor 	= Color.Green;
		private Color 	downHistColor 	= Color.Red;
		private Color 	upHistColor	 	= Color.Green;
		
		private int 	triggerBarIndex = 0;
		private int 	signal 			= 0; 				// 0 = no signal, 1 = buy signal on down trend break, -1 = sell signal on up trend break
		private int     direction		= 0;				// 0 = Undefined or broken trend, 1=active up trend, -1=active down trend
		private double	trendPrice		= 0;
		private int     lineWidth 		= 1;
		private int 	lineCount 		= 0;
		private double	startBarPriceOld= 0;
		
		private string	atmStrategyId		= string.Empty;
		private string	orderId				= string.Empty;
		
		bool isOrderPresent = false;
		
        // User defined variables (add any user defined variables below)
        //#endregion

		

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			
            CalculateOnBarClose = true;
					

        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
		
        protected override void OnBarUpdate()
        {	
			GetTrend();
				
			if(DateTime.Now.CompareTo(new DateTime(2015,3,30)) < 0)
			SetLowAndHigh();
			
        }
		
		private void SetLowAndHigh(){
			_numLow = Low[Period];
			_numHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(_numLow < Low[bar]){
					_numLow = Low[bar];
				}
				if(_numHigh > High[bar]){
					_numHigh = High[bar];
				}
			}
		}
		
		
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
				_price = e.Price;
								
				ChangeOnPriceUpdate(_price);
			}
			
				
		}
		
		
		private void ChangeOnPriceUpdate(double price){

			BuyOrSell(price);
			
		}
		

		
		
		private void BuyOrSell(double price){

			Print("IsLongTrend -> " + IsLongTrend);
			if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
				atmStrategyId = GetAtmStrategyUniqueId();
				orderId = GetAtmStrategyUniqueId();
				if(!IsLongTrend){
					if(price > _numLow && GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){// upper then green line
						if(GetAtmStrategyMarketPosition(atmStrategyId) != MarketPosition.Flat){
							Print ("HAVE ANY ORDER");
						}
						else if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
							//atmStrategyId = GetAtmStrategyUniqueId();
							//orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Sell, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
						}
					}
				}
				else 
				if(IsLongTrend){
					if(price < _numHigh && GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
						if(GetAtmStrategyMarketPosition(atmStrategyId) != MarketPosition.Flat){
							Print ("HAVE ANY ORDER");
						}
						else 
						if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
							//atmStrategyId = GetAtmStrategyUniqueId();
							//orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Buy, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);   	
						}
					}
				}
			}
		}
		
		private void GetTrend(){
		
			//DETERMINE LOCATION OF LAST UP/DOWN TREND LINES	
			signal = 0;
			int upTrendOccurence 		= 1;	int upTrendStartBarsAgo		= 0;	int upTrendEndBarsAgo 		= 0;
			int downTrendOccurence 		= 1;	int	downTrendStartBarsAgo	= 0;	int	downTrendEndBarsAgo 	= 0;
		// Only calculate new autotrend line if ray hasent been put into manual mode by unlocking current ray
		if ( ((DrawObjects["UpTrendRay"] ==null) || (DrawObjects["UpTrendRay"].Locked)) && ((DrawObjects["DownTrendRay"] ==null) || (DrawObjects["DownTrendRay"].Locked)) ) 
//		if (  (DrawObjects["UpTrendRay"].Locked) || (DrawObjects["DowntrendTrendRay"].Locked) ) 
		{//Only do the following if existing ray is in auto mode	
		// Calculate up trend line
			upTrendOccurence 		= 1;	
			while (Low[upTrendEndBarsAgo] <= Low[upTrendStartBarsAgo])
			{	upTrendStartBarsAgo 	= Swing(strength).SwingLowBar(0, upTrendOccurence + 1, CurrentBar);
				upTrendEndBarsAgo 	= Swing(strength).SwingLowBar(0, upTrendOccurence, CurrentBar);
				if (upTrendStartBarsAgo < 0 || upTrendEndBarsAgo < 0)
					break;
				upTrendOccurence++;
			}
		// Calculate down trend line	
			downTrendOccurence 		= 1;
			while (High[downTrendEndBarsAgo] >= High[downTrendStartBarsAgo])
			{	downTrendStartBarsAgo 		= Swing(strength).SwingHighBar(0, downTrendOccurence + 1, CurrentBar);
				downTrendEndBarsAgo 		= Swing(strength).SwingHighBar(0, downTrendOccurence, CurrentBar);
				if (downTrendStartBarsAgo < 0 || downTrendEndBarsAgo < 0)
					break;
				downTrendOccurence++;
			}
		 }	
		// Clear out arrows that mark trend line breaks unless ShowHistory flag is true
			if (!showHistory) RemoveDrawObject("DownTrendBreak");							
			if (!showHistory) RemoveDrawObject("UpTrendBreak");
			
	//PROCESS UPTREND LINE IF CURRENT
			if (upTrendStartBarsAgo > 0 && upTrendEndBarsAgo > 0 && upTrendStartBarsAgo < downTrendStartBarsAgo)
			{	
				Print("Now LONG Trend Line");
				IsLongTrend = true;
				RemoveDrawObject("DownTrendRay");
				double startBarPrice 	= Low[upTrendStartBarsAgo];
				double endBarPrice 		= Low[upTrendEndBarsAgo];
				double changePerBar 	= (endBarPrice - startBarPrice) / (Math.Abs(upTrendEndBarsAgo - upTrendStartBarsAgo));
			//Test to see if this is a new trendline and increment lineCounter if so.
				if (startBarPrice!=startBarPriceOld)	
				{	direction=1;  //Signal that we have a new uptrend and put dot on trendline where new trend detected
					DrawDot(CurrentBar.ToString(), true, 0, startBarPrice+(upTrendStartBarsAgo*changePerBar), UpTrendColor);
					lineCount=lineCount+1;	
					triggerBarIndex = 0;
					ResetAlert("Alert");
				}
				startBarPriceOld=startBarPrice;
				//
			// Draw the up trend line
			// If user has unlocked the ray use manual rays position instead of auto generated positions to track ray position
				if ( (DrawObjects["UpTrendRay"] !=null) && (!DrawObjects["UpTrendRay"].Locked) )
				{	IRay upTrendRay		= (IRay) DrawObjects["UpTrendRay"];	
					//startBarPrice 		= upTrendRay.Anchor1Y;
					//endBarPrice 		= upTrendRay.Anchor2Y;
					upTrendStartBarsAgo = upTrendRay.Anchor1BarsAgo;
					upTrendEndBarsAgo   = upTrendRay.Anchor2BarsAgo;
					//changePerBar 		= (endBarPrice - startBarPrice)/(Math.Abs(upTrendRay.Anchor2BarsAgo-upTrendRay.Anchor1BarsAgo));
					//upTrendRay.Pen.DashStyle=DashStyle.Dash;
					//upTrendRay.Pen.Color=Color.Blue;
				}
				//else
				//{	DrawRay("UpTrendRay", false, upTrendStartBarsAgo, startBarPrice, upTrendEndBarsAgo, endBarPrice, UpTrendColor, DashStyle.Solid, lineWidth);
				//}
			//Draw the history line that will stay persistent on chart using lineCounter to establish a unique name
				
				//if (showHistory) DrawLine("HistoryLine"+lineCount.ToString(), false, upTrendStartBarsAgo, startBarPrice, 0, startBarPrice+(upTrendStartBarsAgo*changePerBar), UpHistColor, DashStyle.Solid, lineWidth);
		
				//SET RETURN VALUES FOR INDICATOR
			// Check for an uptrend line break
				
				/*trendPrice=(startBarPrice+(upTrendStartBarsAgo*changePerBar));
				for (int barsAgo = upTrendEndBarsAgo - 1; barsAgo >= 0; barsAgo--) 
				{	if (Close[barsAgo] < endBarPrice + (Math.Abs(upTrendEndBarsAgo - barsAgo) * changePerBar))
					{	if (showHistory) 
						{	DrawArrowDown("UpTrendBreak"+lineCount.ToString(), barsAgo, High[barsAgo] + TickSize, downTrendColor); }
						else
						{	DrawArrowDown("UpTrendBreak", barsAgo, High[barsAgo] + TickSize, downTrendColor); }
			// Set the break signal only if the break is on the right most bar
						if (barsAgo == 0)
							signal = -1;
			// Alert will only trigger in real-time
						if (AlertOnBreak && triggerBarIndex == 0)
						{	triggerBarIndex = CurrentBar - upTrendEndBarsAgo;
							Alert("Alert", Priority.High, "Up trend line broken", "Alert2.wav", 100000, Color.Black, Color.Red);
						}
						break;
					}	
				}
				*/
			}


			else 
	//DETECT AND PROCESS DOWNTREND LINE	IF CURRENT	
			if (downTrendStartBarsAgo > 0 && downTrendEndBarsAgo > 0  && upTrendStartBarsAgo > downTrendStartBarsAgo)
			{	
				Print("Now DOWN Trend Line");
				IsLongTrend = false;
				RemoveDrawObject("UpTrendRay");
				double startBarPrice 	= High[downTrendStartBarsAgo];
				double endBarPrice 		= High[downTrendEndBarsAgo];
				double changePerBar 	= (endBarPrice - startBarPrice) / (Math.Abs(downTrendEndBarsAgo - downTrendStartBarsAgo));
			//Test to see if this is a new trendline and increment lineCount if so.
				if (startBarPrice!=startBarPriceOld)	
				{	direction=-1;		//signl that we have a new downtrend
					DrawDot(CurrentBar.ToString(), true, 0, startBarPrice+(downTrendStartBarsAgo*changePerBar), DownTrendColor);
					lineCount=lineCount+1;	
					triggerBarIndex = 0;
					ResetAlert("Alert");
				}
				startBarPriceOld=startBarPrice;
				//
			// Draw the down trend line
				// If user has unlocked the ray use manual rays position instead
				if ( (DrawObjects["DownTrendRay"] !=null) && (!DrawObjects["DownTrendRay"].Locked) )
				{	IRay downTrendRay	= (IRay) DrawObjects["DownTrendRay"];	
				//	startBarPrice 		= downTrendRay.Anchor1Y;
				//	endBarPrice 		= downTrendRay.Anchor2Y;;
					downTrendStartBarsAgo = downTrendRay.Anchor1BarsAgo;
					downTrendEndBarsAgo   = downTrendRay.Anchor2BarsAgo;
				//	changePerBar 		= (endBarPrice - startBarPrice)/(Math.Abs(downTrendRay.Anchor2BarsAgo-downTrendRay.Anchor1BarsAgo));
				//	downTrendRay.Pen.DashStyle=DashStyle.Dash;
				//	downTrendRay.Pen.Color=Color.Blue;

				}
				//else			
				//{	DrawRay("DownTrendRay", false, downTrendStartBarsAgo, startBarPrice, downTrendEndBarsAgo, endBarPrice, DownTrendColor, DashStyle.Solid, lineWidth);
				//}
				//if (showHistory) DrawLine("HistoryLine"+lineCount.ToString(), false, downTrendStartBarsAgo, startBarPrice, 0, startBarPrice+(downTrendStartBarsAgo*changePerBar), downHistColor, DashStyle.Solid, lineWidth);
		//SET RETURN VALUES FOR INDICATOR
			// Check for a down trend line break
				/*
				trendPrice=(startBarPrice+(downTrendStartBarsAgo*changePerBar));
				for (int barsAgo = downTrendEndBarsAgo - 1; barsAgo >= 0; barsAgo--) 
				{//	direction=-1;
					if (Close[barsAgo] > endBarPrice + (Math.Abs(downTrendEndBarsAgo - barsAgo) * changePerBar))
					{	if (showHistory) 
						{	DrawArrowUp("DownTrendBreak"+lineCount.ToString(), barsAgo, Low[barsAgo] - TickSize, upTrendColor); }
						else
						{	DrawArrowUp("DownTrendBreak", barsAgo, Low[barsAgo] - TickSize, upTrendColor); }
					// Set the break signal only if the break is on the right most bar
						if (barsAgo == 0)
							signal = 1;
					// Alert will only trigger in real-time
						if (AlertOnBreak && triggerBarIndex == 0)
						{	triggerBarIndex = CurrentBar - downTrendEndBarsAgo;
							Alert("Alert", Priority.High, "Down trend line broken", "Alert2.wav", 100000, Color.Black, Color.Green);
						}
						break;
					}
				}*/
			}		
		}
		
		#region Indicator Get\Set
		/*[Description("Generates a visual and audible alert on a trend line break")]
        [Category("Parameters")]
        public bool AlertOnBreak
        {
            get { return alertOnBreak; }
            set { alertOnBreak = value; }
        }
		*/
		
		[Description("Number of bars required on each side swing pivot points used to connect the trend lines")]
        [Category("Parameters")]
        public int Strength
        {
            get { return strength; }
            set { strength = Math.Max(1, value); }
        }
/*
		[Description("Show Historical Trendlines & Breaks")]
        [Category("Parameters")]
        public bool ShowHistory
        {
            get { return showHistory; }
            set { showHistory = value; }
        }
		*/
		/// <summary>
		/// Gets the trade signal. 0 = no signal, 1 = Buy signal on break of down trend line, -1 = Sell signal on break of up trend line
		/// </summary>
		/// <returns></returns>
		//public int Signal
		//{
		//	get { Update(); return signal; }
		//}
		/// <summary>
		/// Gets Trend Direction
		/// </summary>
		//[Browsable(false)]
		//[XmlIgnore()]
		//public int Direction
		//{
		//	get { Update(); return direction; }
		//}

		/// <summary>
		/// Gets TrendPrice
		/// </summary>
		//[Browsable(false)]
		//[XmlIgnore()]
		//public double TrendPrice
		//{
		//	get { Update(); return trendPrice; }
		//}

		/// <summary>
		/// </summary>
		[XmlIgnore()]
		[Description("Color of the down trend line.")]
		[Category("Colors")]
		[Gui.Design.DisplayNameAttribute("Down trend")]
		public Color DownTrendColor
		{
			get { return downTrendColor; }
			set { downTrendColor = value; }
		}

		/// <summary>
		/// </summary>
		[Browsable(false)]
		public string DownTrendColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(downTrendColor); }
			set { downTrendColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[XmlIgnore()]
		[Description("Color of the up trend line.")]
		[Category("Colors")]
		[Gui.Design.DisplayNameAttribute("Up trend")]
		public Color UpTrendColor
		{
			get { return upTrendColor; }
			set { upTrendColor = value; }
		}

		/// <summary>
		/// </summary>
		[Browsable(false)]
		public string UpTrendColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upTrendColor); }
			set { upTrendColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[XmlIgnore()]
		[Description("Color of History down trend line.")]
		[Category("Colors")]
		[Gui.Design.DisplayNameAttribute("History Down trend")]
		public Color DownHistColor
		{
			get { return downHistColor; }
			set { downHistColor = value; }
		}

		/// <summary>
		/// </summary>
		[Browsable(false)]
		public string DownHistColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(downHistColor); }
			set { downHistColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[XmlIgnore()]
		[Description("Color of the History up trend line.")]
		[Category("Colors")]
		[Gui.Design.DisplayNameAttribute("History Up trend")]
		public Color UpHistColor
		{
			get { return upHistColor; }
			set { upHistColor = value; }
		}

		/// <summary>
		/// </summary>
		[Browsable(false)]
		public string UpHistColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upHistColor); }
			set { upHistColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
        #endregion
		
        #region Properties		
		[Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set { _period = Math.Max(1, value); }
        }
	

       
		
		//[Description("")]
        //[GridCategory("Parameters")]
        private bool IsLongTrend
        {
            get { return _isLongTrend; }
            set { _isLongTrend = value; }
        }
		
        #endregion
    }
}
