#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSReversBarEMA : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType;
		
		private bool isBreakevenEnable = false;
		private bool isCanEnterOrder = false;
		
		
		private double previousFastEMA = 0;
		private double currentFastEMA = 0;
		
		private double previousSlowEMA = 0;
		private double currentSlowEMA = 0;

		private double stopLossPrice = 0;
		
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			

			//if (CrossAbove(EMA(Fast), EMA(Slow), 1))
			previousFastEMA = currentFastEMA;
			currentFastEMA = EMA(Fast)[0];
			
			previousSlowEMA = currentSlowEMA;
			currentSlowEMA = EMA(Slow)[0];
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				//if (CrossAbove(EMA(Fast), EMA(Slow), 1))
				if(previousFastEMA < currentSlowEMA && currentFastEMA > currentSlowEMA)
				{
					SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
					
					orderType = OrderType.BUY;
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					
				}
				//else if (CrossBelow(EMA(Fast), EMA(Slow), 1))
				else if(previousFastEMA > currentSlowEMA && currentFastEMA < currentSlowEMA)
				{	
					SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
					orderType = OrderType.SELL;
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					
				}
				else
				{
					isCanEnterOrder = false;
				}
			}
			
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
			
				if (Position.MarketPosition == MarketPosition.Flat)
				{
					if(isCanEnterOrder && orderType == OrderType.SELL)
					{
						isCanEnterOrder = false;
						startOrderPrice = e.Price;
						Print("---------------");
						Print("Sell startOrderPrice -> " + startOrderPrice);
						EnterShort("Order");
					}
					else if(isCanEnterOrder && orderType == OrderType.BUY)
					{
						isCanEnterOrder = false;
						startOrderPrice = e.Price;
						Print("---------------");
						Print("Buy startOrderPrice -> " + startOrderPrice);
						EnterLong("Order");
					}
				}
				
				if (Position.MarketPosition != MarketPosition.Flat)
				{
					
					if(BreakevenSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY)
						{
							if(startOrderPrice + BreakevenAfterTicks * TickSize <= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("startOrderPrice -> " + startOrderPrice);
								Print("BuyStopLossBreakeven -> " + (startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						else if(orderType == OrderType.SELL)
						{
							if(startOrderPrice - BreakevenAfterTicks * TickSize >= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("startOrderPrice -> " + startOrderPrice);
								Print("SellStopLossBreakeven -> " + (startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						
						if(isBreakevenEnable)
						{
							if(orderType == OrderType.BUY)
							{
								if(stopLossPrice + DistanceBetweenStopLossAndPriceTicks * TickSize < e.Price)
								{
									stopLossPrice = stopLossPrice + ChangePosition * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Buy Change stoploss " + stopLossPrice);
								}
							}
							else if(orderType == OrderType.SELL)
							{
								if(stopLossPrice - DistanceBetweenStopLossAndPriceTicks * TickSize > e.Price)
								{
									stopLossPrice = stopLossPrice - ChangePosition * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Sell Change stoploss " + stopLossPrice);
								}
							}
							
						}
						
					}
				}
			}
		}
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[GridCategory("Order")]
		public Switch BreakevenSwitch
		{get; set;}

		[GridCategory("Order")]
		public int BreakevenTicksAfterStartOrderPrice
		{get; set;}
		
		[GridCategory("Order")]
		public int BreakevenAfterTicks
		{get; set;}
		
		[GridCategory("Order")]
		public int DefaultStopLoss
		{get; set;}
		
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int DistanceBetweenStopLossAndPriceTicks
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int ChangePosition
		{get; set;}
		
        [Description("")]
        [GridCategory("Parameters")]
        public int Fast
        {
            get { return fast; }
            set { fast = Math.Max(1, value); }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public int Slow
        {
            get { return slow; }
            set { slow = Math.Max(1, value); }
        }

    }
}
