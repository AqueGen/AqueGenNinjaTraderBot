#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Enter the description of your new custom indicator here
    /// </summary>
    [Description("Enter the description of your new custom indicator here")]
    public class AqueGenNinjaBot : Indicator
    {
         //#region Variables
        // Wizard generated variables
        private double _bandPct = 2; // Default setting for BandPct
        private int _period = 20; // Default setting for Period
		private int _newPeriod = 0;
		private int _endDrawLineBar = -1;
	
		private double _numLow = 0;
		private double _numHigh = 0;
	
	    private double _price = 0;
		private double _closeLastPrice = 0;
		
		private double _pointBeforeAlarm = 0.2;
		
		private bool _isFromDownToUp = false;
		private bool _isAlert = true;
		
		private int barIndex = 0;
		
        // User defined variables (add any user defined variables below)
        //#endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Overlay				= true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
    {
		if(CurrentBar < 20)
			return;
		
		
           barIndex++;
			Print("------------------");
			
          	//CalculateOnBarClose = false;
			//double fastPrice = GetWmaPrice(Fast);
          //  double slowPrice = GetWmaPrice(Slow);
          	//CalculateOnBarClose = true;
          
			if(barIndex % Period == 0){
				SetLowAndHigh();
				DrawVerticalLine("tagVertical1", Period, Color.Black);
			}
          	
			Print("Now Bar is -> " + barIndex);
			
			//_numLow = 1199.5;
			//DrawLine("tagNumLow", false, 20, _numLow, _endDrawLineBar, _numLow, Color.Red, DashStyle.Solid, 1);

			//_numHigh = 1199;
			//DrawLine("tagNumHigh", false, 20, _numHigh, _endDrawLineBar, _numHigh, Color.Blue, DashStyle.Solid, 1);
				
			
			
		
		}

		private void SetLowAndHigh(){
			_numLow = Low[Period];
			_numHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(_numLow < Low[bar]){
					_numLow = Low[bar];
					DrawLine("tagNumLow", false, bar, _numLow, -1, _numLow, Color.Green, DashStyle.Solid, 2);
					//DrawHorizontalLine("tag1", 1000, Color.Green);
				}
				if(_numHigh > High[bar]){
					_numHigh = High[bar];
					DrawLine("tagNumHigh", false, bar, _numHigh, -1, _numHigh, Color.Red, DashStyle.Solid, 2);
					//DrawHorizontalLine("tag2", 1000, Color.Red);
				}
			}
		}
	
	
	
	
		private void AlertMessage(double lastPrice, double closePrice, bool isFromDownToUp){
			
			if(!isFromDownToUp){
				if(lastPrice < _numHigh + _pointBeforeAlarm){
					CustomAlert("Цена пересекла нижнюю границу");
					//Process.Start("D://TestAutoIt.exe");
				}
			}
			else{
				if(lastPrice > _numLow - _pointBeforeAlarm){
					CustomAlert("Цена пересекла верхнюю границу");
				}
			}
		}
		
		private void CustomAlert(string message){
			Alert("myAlert", NinjaTrader.Cbi.Priority.High, message, "Alert1.wav", 10, Color.Black, Color.Yellow);
			_isAlert = false;
		}
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			// Print some data to the Output window
			if (e.MarketDataType == MarketDataType.Last) {
				_price = e.Price;
				
				if(_price >= Close[0])
					_isFromDownToUp = true;
				else
					_isFromDownToUp = false;

				if(_isAlert){
					AlertMessage(_price, Close[0], _isFromDownToUp);
				}
			}
			
			
		}

		
		
        //#region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Lower
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Upper
        {
            get { return Values[1]; }
        }

        [Description("Deviation factor")]
        [GridCategory("Parameters")]
        private double BandPct
        {
            get { return _bandPct; }
            set { _bandPct = Math.Max(1, value); }
        }

        [Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set 
			{ 
				_period = Math.Max(1, value);
				_newPeriod = Convert.ToInt32(Math.Sqrt(Convert.ToDouble(value)));
			}
        }
        //#endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private AqueGenNinjaBot[] cacheAqueGenNinjaBot = null;

        private static AqueGenNinjaBot checkAqueGenNinjaBot = new AqueGenNinjaBot();

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public AqueGenNinjaBot AqueGenNinjaBot(int period)
        {
            return AqueGenNinjaBot(Input, period);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public AqueGenNinjaBot AqueGenNinjaBot(Data.IDataSeries input, int period)
        {
            if (cacheAqueGenNinjaBot != null)
                for (int idx = 0; idx < cacheAqueGenNinjaBot.Length; idx++)
                    if (cacheAqueGenNinjaBot[idx].Period == period && cacheAqueGenNinjaBot[idx].EqualsInput(input))
                        return cacheAqueGenNinjaBot[idx];

            lock (checkAqueGenNinjaBot)
            {
                checkAqueGenNinjaBot.Period = period;
                period = checkAqueGenNinjaBot.Period;

                if (cacheAqueGenNinjaBot != null)
                    for (int idx = 0; idx < cacheAqueGenNinjaBot.Length; idx++)
                        if (cacheAqueGenNinjaBot[idx].Period == period && cacheAqueGenNinjaBot[idx].EqualsInput(input))
                            return cacheAqueGenNinjaBot[idx];

                AqueGenNinjaBot indicator = new AqueGenNinjaBot();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Period = period;
                Indicators.Add(indicator);
                indicator.SetUp();

                AqueGenNinjaBot[] tmp = new AqueGenNinjaBot[cacheAqueGenNinjaBot == null ? 1 : cacheAqueGenNinjaBot.Length + 1];
                if (cacheAqueGenNinjaBot != null)
                    cacheAqueGenNinjaBot.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheAqueGenNinjaBot = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.AqueGenNinjaBot AqueGenNinjaBot(int period)
        {
            return _indicator.AqueGenNinjaBot(Input, period);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.AqueGenNinjaBot AqueGenNinjaBot(Data.IDataSeries input, int period)
        {
            return _indicator.AqueGenNinjaBot(input, period);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.AqueGenNinjaBot AqueGenNinjaBot(int period)
        {
            return _indicator.AqueGenNinjaBot(Input, period);
        }

        /// <summary>
        /// Enter the description of your new custom indicator here
        /// </summary>
        /// <returns></returns>
        public Indicator.AqueGenNinjaBot AqueGenNinjaBot(Data.IDataSeries input, int period)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.AqueGenNinjaBot(input, period);
        }
    }
}
#endregion
