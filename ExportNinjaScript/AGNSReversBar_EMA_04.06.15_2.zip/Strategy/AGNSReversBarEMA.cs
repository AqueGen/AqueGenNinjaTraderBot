#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSReversBarEMA : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType;
		
		private bool isBreakevenEnable = false;
		private bool isCanEnterOrder = false;
		
		
		private double previousFastEMA = 0;
		private double currentFastEMA = 0;
		
		private double previousSlowEMA = 0;
		private double currentSlowEMA = 0;

		private double stopLossPrice = 0;
		
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			

			previousFastEMA = currentFastEMA;
			previousSlowEMA = currentSlowEMA;
			
			if(FastInputSeries == InputSeries.CLOSE)
			{
				currentFastEMA = EMA(Close, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.HIGH)
			{
				currentFastEMA = EMA(High, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.LOW)
			{
				currentFastEMA = EMA(Low, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.MEDIAN)
			{
				currentFastEMA = EMA(Median, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.OPEN)
			{
				currentFastEMA = EMA(Open, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.TYPICAL)
			{
				currentFastEMA = EMA(Typical, Fast)[0];
			}
			else if(FastInputSeries == InputSeries.WEIGHTED)
			{
				currentFastEMA = EMA(Weighted, Fast)[0];
			}
			
			if(SlowInputSeries == InputSeries.CLOSE)
			{
				currentSlowEMA = EMA(Close, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.HIGH)
			{
				currentSlowEMA = EMA(High, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.LOW)
			{
				currentSlowEMA = EMA(Low, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.MEDIAN)
			{
				currentSlowEMA = EMA(Median, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.OPEN)
			{
				currentSlowEMA = EMA(Open, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.TYPICAL)
			{
				currentSlowEMA = EMA(Typical, Slow)[0];
			}
			else if(SlowInputSeries == InputSeries.WEIGHTED)
			{
				currentSlowEMA = EMA(Weighted, Slow)[0];
			}

			
			Print("currentSlowEMA " + currentSlowEMA);
			Print("currentFastEMA " + currentFastEMA);
			
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				//if (CrossAbove(EMA(Fast), EMA(Slow), 1))
				if(previousFastEMA < currentSlowEMA && currentFastEMA > currentSlowEMA)
				{
					SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
					
					orderType = OrderType.BUY;
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					
				}
				//else if (CrossBelow(EMA(Fast), EMA(Slow), 1))
				else if(previousFastEMA > currentSlowEMA && currentFastEMA < currentSlowEMA)
				{	
					SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
					orderType = OrderType.SELL;
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					
				}
				else
				{
					isCanEnterOrder = false;
				}
			}
			
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
			
				if (Position.MarketPosition == MarketPosition.Flat)
				{
					if(isCanEnterOrder && orderType == OrderType.SELL)
					{
						isCanEnterOrder = false;
						startOrderPrice = e.Price;
						Print("---------------");
						Print("Sell startOrderPrice -> " + startOrderPrice);
						EnterShort("Order");
					}
					else if(isCanEnterOrder && orderType == OrderType.BUY)
					{
						isCanEnterOrder = false;
						startOrderPrice = e.Price;
						Print("---------------");
						Print("Buy startOrderPrice -> " + startOrderPrice);
						EnterLong("Order");
					}
				}
				
				if (Position.MarketPosition != MarketPosition.Flat)
				{
					
					if(BreakevenSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY)
						{
							if(startOrderPrice + BreakevenAfterTicks * TickSize <= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("startOrderPrice -> " + startOrderPrice);
								Print("BuyStopLossBreakeven -> " + (startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						else if(orderType == OrderType.SELL)
						{
							if(startOrderPrice - BreakevenAfterTicks * TickSize >= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("startOrderPrice -> " + startOrderPrice);
								Print("SellStopLossBreakeven -> " + (startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						
						if(isBreakevenEnable)
						{
							if(orderType == OrderType.BUY)
							{
								if(stopLossPrice + PriceTarget * TickSize < e.Price)
								{
									stopLossPrice = stopLossPrice + StopUnderPrice * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Buy Change stoploss " + stopLossPrice);
								}
							}
							else if(orderType == OrderType.SELL)
							{
								if(stopLossPrice - PriceTarget * TickSize > e.Price)
								{
									stopLossPrice = stopLossPrice - StopUnderPrice * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Sell Change stoploss " + stopLossPrice);
								}
							}
							
						}
						
					}
				}
			}
		}
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL
		}
		
		public enum InputSeries
		{
			CLOSE,
			HIGH,
			LOW,
			MEDIAN,
			OPEN,
			TYPICAL,
			WEIGHTED
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[GridCategory("Order")]
		public Switch BreakevenSwitch
		{get; set;}

		[GridCategory("Order")]
		public int BreakevenTicksAfterStartOrderPrice
		{get; set;}
		
		[GridCategory("Order")]
		public int BreakevenAfterTicks
		{get; set;}
		
		[GridCategory("Order")]
		public int DefaultStopLoss
		{get; set;}
		
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int PriceTarget
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int StopUnderPrice
		{get; set;}
		
        [Description("")]
        [GridCategory("EMA")]
        public int Fast
        {
            get { return fast; }
            set { fast = Math.Max(1, value); }
        }
		[Description("")]
        [GridCategory("EMA")]
        public int Slow
        {
            get { return slow; }
            set { slow = Math.Max(1, value); }
        }
		[GridCategory("EMA")]
		public InputSeries FastInputSeries
		{get; set;}
		
		[GridCategory("EMA")]
		public InputSeries SlowInputSeries
		{get; set;}



    }
}
