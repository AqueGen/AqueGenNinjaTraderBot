#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class CCIStrategy : Strategy
    {
		private int	period		= 14;
		
		private Cci cci;

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            SetStopLoss("", CalculationMode.Ticks, StopLossTicks, false);
            SetProfitTarget("", CalculationMode.Ticks, ProfitTargetTicks);

            CalculateOnBarClose = true;
			
			SyncAccountPosition = true;
			RealtimeErrorHandling = RealtimeErrorHandling.TakeNoAction; 
        }

		
		protected override void OnStartUp()
		{
			cci = new Cci();
		}
		
        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			
			Print("------");
			Print(Time[0]);
			
			cci.PreviousCci = cci.CurrentCci;
			cci.CurrentCci = CCI(Period)[0];
			
			Print("Previous CCI: " + cci.PreviousCci);
			Print("Current CCI: " + cci.CurrentCci);
			Print("Current CCI2: " + CCIOnBarUpdate());

			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				if(cci.PreviousCci < 0 && cci.CurrentCci > 0)
				{
					
					Print("=========");
					Print("Local time: " + DateTime.Now);
					Print("OrderAction.Buy");
					Print("=========");
					EnterLong("");
				}
				else if(cci.PreviousCci > 0 && cci.CurrentCci < 0)
				{
					Print("=========");
					Print("OrderAction.Sell");
					Print("=========");
					EnterShort("");
				}
			}
        }
		
		
		public class Cci
		{
			public double PreviousCci
			{get; set;}
			public double CurrentCci
			{get; set;}
		}
		
		protected double CCIOnBarUpdate()
		{
			if (CurrentBar == 0)
				return 0;
			else
			{
				double mean = 0;
				for (int idx = Math.Min(CurrentBar, Period - 1); idx >= 0; idx--)
					mean += Math.Abs(Typical[idx] - SMA(Typical, Period)[0]);
				return (Typical[0] - SMA(Typical, Period)[0]) / (mean == 0 ? 1 : (0.015 * (mean / Math.Min(Period, CurrentBar + 1))));
			}
		}
		

		public enum Switch
		{
			ON,
			OFF
		}
		
        #region Properties

		[Description("Numbers of bars used for calculations")]
		[GridCategory("Parameters")]
		public int Period
		{
			get { return period; }
			set { period = Math.Max(1, value); }
		}
		
				
		[Description("Numbers of bars used for calculations")]
		[GridCategory("Order")]
		public int StopLossTicks
		{get; set;}
		
				
		[Description("Numbers of bars used for calculations")]
		[GridCategory("Order")]
		public int ProfitTargetTicks
		{get; set;}
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
        #endregion
    }
}
