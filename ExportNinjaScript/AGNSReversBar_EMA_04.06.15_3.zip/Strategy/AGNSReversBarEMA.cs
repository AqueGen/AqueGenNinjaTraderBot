#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSReversBarEMA : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType;
		
		private bool isBreakevenEnable = false;
		private bool isCanEnterOrder = false;
		
		
		private double previousFastEMA = 0;
		private double currentFastEMA = 0;
		
		private double previousSlowEMA = 0;
		private double currentSlowEMA = 0;

		private double stopLossPrice = 0;
		
		
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			
			if (Historical == true)
			{
				return;
			}
			
			IDataSeries fastDataSeries = Close;
			IDataSeries slowDataSeries = Close;

			if(FastInputSeries == InputSeries.CLOSE)
			{
				fastDataSeries = Close;
			}
			else if(FastInputSeries == InputSeries.HIGH)
			{
				fastDataSeries = High;
			}
			else if(FastInputSeries == InputSeries.LOW)
			{
				fastDataSeries = Low;
			}
			else if(FastInputSeries == InputSeries.MEDIAN)
			{
				fastDataSeries = Median;
			}
			else if(FastInputSeries == InputSeries.OPEN)
			{
				fastDataSeries = Open;
			}
			else if(FastInputSeries == InputSeries.TYPICAL)
			{
				fastDataSeries = Typical;
			}
			else if(FastInputSeries == InputSeries.WEIGHTED)
			{
				fastDataSeries = Weighted;
			}
			
			if(SlowInputSeries == InputSeries.CLOSE)
			{
				slowDataSeries = Close;
			}
			else if(SlowInputSeries == InputSeries.HIGH)
			{
				slowDataSeries = High;
			}
			else if(SlowInputSeries == InputSeries.LOW)
			{
				slowDataSeries = Low;
			}
			else if(SlowInputSeries == InputSeries.MEDIAN)
			{
				slowDataSeries = Median;
			}
			else if(SlowInputSeries == InputSeries.OPEN)
			{
				slowDataSeries = Open;
			}
			else if(SlowInputSeries == InputSeries.TYPICAL)
			{
				slowDataSeries = Typical;
			}
			else if(SlowInputSeries == InputSeries.WEIGHTED)
			{
				slowDataSeries = Weighted;
			}
	
			
			

			if (CrossAbove(EMA(fastDataSeries, Fast), EMA(slowDataSeries, Slow), 1))
			{
				SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
				
				if(orderType == OrderType.SELL)
				{
					isCanEnterOrder = true;
					Print("---------------");
					Print("Can Enter Order BUY");
				}
				else if(orderType == OrderType.BUY)
				{
					isCanEnterOrder = false;
				}
				
				orderType = OrderType.BUY;

				isBreakevenEnable = false;
				
			}
			else if (CrossBelow(EMA(fastDataSeries, Fast), EMA(slowDataSeries, Slow), 1))
			{	
				SetStopLoss("Order", CalculationMode.Ticks, DefaultStopLoss, false);
				
				if(orderType == OrderType.BUY)
				{
					isCanEnterOrder = true;
					Print("---------------");
					Print("Can Enter Order SELL");
				}
				else if(orderType == OrderType.SELL)
				{
					isCanEnterOrder = false;
				}
				
				orderType = OrderType.SELL;
				isBreakevenEnable = false;
				
			}

			
			
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
			
				if(isCanEnterOrder && orderType == OrderType.SELL)
				{
					isCanEnterOrder = false;
					startOrderPrice = e.Price;
					Print("Sell startOrderPrice -> " + startOrderPrice);
					EnterShort("Order");
				}
				else if(isCanEnterOrder && orderType == OrderType.BUY)
				{
					isCanEnterOrder = false;
					startOrderPrice = e.Price;
					Print("Buy startOrderPrice -> " + startOrderPrice);
					EnterLong("Order");
				}
				
				
				if (Position.MarketPosition != MarketPosition.Flat)
				{
					
					if(BreakevenSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY)
						{
							if(startOrderPrice + BreakevenAfterTicks * TickSize <= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("BuyStopLossBreakeven -> " + (startOrderPrice + BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						else if(orderType == OrderType.SELL)
						{
							if(startOrderPrice - BreakevenAfterTicks * TickSize >= e.Price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("SellStopLossBreakeven -> " + (startOrderPrice - BreakevenTicksAfterStartOrderPrice * TickSize));
							}
						}
						
						if(isBreakevenEnable)
						{
							if(orderType == OrderType.BUY)
							{
								if(stopLossPrice + PriceTarget * TickSize < e.Price)
								{
									stopLossPrice = stopLossPrice + StopUnderPrice * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Buy Change stoploss " + stopLossPrice);
								}
							}
							else if(orderType == OrderType.SELL)
							{
								if(stopLossPrice - PriceTarget * TickSize > e.Price)
								{
									stopLossPrice = stopLossPrice - StopUnderPrice * TickSize;
									SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
									Print("Sell Change stoploss " + stopLossPrice);
								}
							}
							
						}
						
					}
				}
			}
		}
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL
		}
		
		public enum InputSeries
		{
			CLOSE,
			HIGH,
			LOW,
			MEDIAN,
			OPEN,
			TYPICAL,
			WEIGHTED
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[GridCategory("Order")]
		public Switch BreakevenSwitch
		{get; set;}

		[GridCategory("Order")]
		public int BreakevenTicksAfterStartOrderPrice
		{get; set;}
		
		[GridCategory("Order")]
		public int BreakevenAfterTicks
		{get; set;}
		
		[GridCategory("Order")]
		public int DefaultStopLoss
		{get; set;}
		
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int PriceTarget
		{get; set;}
		
		[GridCategory("TrailStop")]
		public int StopUnderPrice
		{get; set;}
		
        [Description("")]
        [GridCategory("EMA")]
        public int Fast
        {
            get { return fast; }
            set { fast = Math.Max(1, value); }
        }
		[Description("")]
        [GridCategory("EMA")]
        public int Slow
        {
            get { return slow; }
            set { slow = Math.Max(1, value); }
        }
		[GridCategory("EMA")]
		public InputSeries FastInputSeries
		{get; set;}
		
		[GridCategory("EMA")]
		public InputSeries SlowInputSeries
		{get; set;}



    }
}
