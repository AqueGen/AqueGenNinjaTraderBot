#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSUnirenkoLimits : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType = OrderType.FLAT;
		
		private bool isCanEnterOrder = false;
		private bool isOrderNotChanged = false;
		
		
		private double stopLossPrice = 0;
		private double trailStopLossPrice = 0;
		
		private bool isTrailStopEnable = false;
		
		private bool isNewBar = false;
		
		private int orderEnterBar = 0;
		
		private OrderType previousActiveOrder = OrderType.FLAT;
		private OrderType currentActiveOrder = OrderType.FLAT;
		
		private Bar previousBar = null;
		private Bar currentBar = null;
		
		private double Price;

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			//SetStopLoss(50);
			//SetProfitTarget(50);
        }

		protected override void OnTermination()
		{

		}
		
		protected override void OnStartUp()
		{
			previousBar = new Bar
			{
				High = High[1],
				Low = Low[1]
			};
			currentBar = new Bar
			{
				High = High[0],
				Low = Low[0]
			};
		}
		
        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}	
			if (Historical == true)
			{
				return;
			}	
			
			
			previousBar = currentBar;
			currentBar = new Bar
			{
				High = High[0],
				Low = Low[0]
			};
		
			isNewBar = true;
			
			Print("-----------");
			if(previousBar.Low > currentBar.Low/* && previousBar.High > currentBar.High*/)
			{
				//if(Price < currentBar.Low)
				{
					EnterLongStopLimit(currentBar.High + 1, currentBar.High + 1);
					Print(Time[0]);
					Print("Price " + Price);
					Print("Enter Long Limit " + (currentBar.High + 1));
					Print("Enter Long Stop " + (currentBar.High + 1));
					//orderType = OrderType.BUY;
				}

			}
			else if(/*previousBar.Low < currentBar.Low &&*/ previousBar.High < currentBar.High)
			{
				//if(Price > currentBar.High)
				{
					EnterShortStopLimit(currentBar.Low - 1, currentBar.Low - 1);
					Print(Time[0]);
					Print("Price " + Price);
					Print("Enter Short Limit " + (currentBar.Low - 1));
					Print("Enter Short Stop " + (currentBar.Low - 1));
					//orderType = OrderType.SELL;
				}
			}
			orderType = OrderType.FLAT;
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) 
			{
				Price = e.Price;
				
			
					if(Position.MarketPosition == MarketPosition.Long)
					{
						if(currentBar.High > Price)
						{
							Print("Enter Sell in current bar");
							Print("Price " + Price);
							//orderType = OrderType.SELL;
							EnterShort();
						}
					}
				
					if(Position.MarketPosition == MarketPosition.Short)
					{		
						if(currentBar.Low < Price)
						{
							Print("Enter Buy in current bar");
							Print("Price " + Price);
							//orderType = OrderType.BUY;
							EnterLong();
						}
					}

				
				
				

				if(TrailStopSwitch == Switch.ON)
				{
					if(orderType == OrderType.BUY && startOrderPrice + ProfitTrigger * TickSize <= Price)
					{
						if(!isTrailStopEnable)
						{
							Print("Trail ON");
							isTrailStopEnable = true;
							trailStopLossPrice = Price - TrailStop * TickSize;
							Print("Buy Change TrailStop " + trailStopLossPrice);
							Print("price -> " + Price);
						}
						
						if(trailStopLossPrice + TrailStop * TickSize+ Frequency * TickSize <= Price && isTrailStopEnable)
						{
							trailStopLossPrice = Price - TrailStop * TickSize;
							SetStopLoss("Order", CalculationMode.Price, trailStopLossPrice, false);
							Print("Buy Change TrailStop " + trailStopLossPrice);
							Print("price -> " + Price);
						}
					}
					else if(orderType == OrderType.SELL && startOrderPrice - ProfitTrigger * TickSize >= Price)
					{
						if(!isTrailStopEnable)
						{
							Print("Trail ON");
							isTrailStopEnable = true;
							trailStopLossPrice = Price + TrailStop * TickSize;
							Print("Sell Change TrailStop " + trailStopLossPrice);
							Print("price -> " + Price);
						}
						
						if(trailStopLossPrice - TrailStop * TickSize - Frequency * TickSize >= Price && isTrailStopEnable)
						{
							trailStopLossPrice = Price + TrailStop * TickSize;
							SetStopLoss("Order", CalculationMode.Price, trailStopLossPrice, false);
							Print("Sell Change TrailStop " + trailStopLossPrice);
							Print("price -> " + Price);
						}
					}
				}
			}
		}
	
		public class Bar
		{
			public double High {get; set;}
			public double Low {get; set;}
			public double Diapasone
			{
				get
				{
					return High - Low;
				}
			}
			
			public override string  ToString()
			{
				return string.Format("Bar-> High: {0}, Low: {1}", High, Low);
			}
		}
		
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL,
			FLAT
		}
		
		public enum InputSeries
		{
			CLOSE,
			HIGH,
			LOW,
			MEDIAN,
			OPEN,
			TYPICAL,
			WEIGHTED
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[Description("")]
		[GridCategory("Order")]
		public int StopLoss
		{get; set;}
		
		[Description("")]
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[Description("Включить трейлинг через, в тиках")]
		[GridCategory("TrailStop")]
		public int ProfitTrigger
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int TrailStop
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public Switch TrailStopSwitch
		{get; set;}
		
		[Description("Как часто подтягивать стоп-лосс за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int Frequency
		{get; set;}
		

		
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int OpenOffset
		{get; set;}
		
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int TickTrend
		{get; set;}
		
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int TickReversal
		{get; set;}
		



    }
}
