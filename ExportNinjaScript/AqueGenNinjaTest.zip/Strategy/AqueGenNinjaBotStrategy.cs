#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AqueGenNinjaBotStrategy : Strategy
    {
        //#region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
		
		private double _numLow = 0;
		private double _numHigh = 0;
		
		private double _price = 0.0;
		

		private int _period = 20;
		private bool _isLongTrend = true;
		
		private bool isFirstTickTrendInOrder = true;
		private bool isLongTrendFirstTickInOrder;
		
        private int 	strength 		= 5; 		// Default setting for Strength


		private double startOrderPrice = 0;
		
		private string	atmStrategyId		= string.Empty;
		private string	orderId				= string.Empty;
		
		private string openedOrderId;
		private int closeOrderAfterChangeTrendOnTick = 2;
		
		private int currentTimeBars = 1;
		private int trendTimeBars = 5;
		
		private bool isFoundTrend = false;
		
		bool isOrderPresent = false;
		
        // User defined variables (add any user defined variables below)
        //#endregion

		private DataSeries trendFrame;
		//private 

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			
			//Add(PeriodType.Minute, currentTimeBars);
    		Add(PeriodType.Minute, trendTimeBars);
			
			//trendFrame = new DataSeries();
			
			//AutoTrendH(BarsArray[1], false, false, 5).IsUpTrend;
            CalculateOnBarClose = true;
					

        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
		
        protected override void OnBarUpdate()
        {	
			AutoTrendH trend = (AutoTrendH(BarsArray[1], false, false, 5));
			if(trendFrame == null){
				trendFrame = new DataSeries(trend);
			}
			
			if(BarsInProgress == 0){
				Print("Test 1 min Bar");
			}
			//IsLongTrend = GetTrend();
			isFoundTrend = true;
			if(BarsInProgress == 1){
				Print("Test 5 min Bar");
				trendFrame.Set(1500);
				Print("AutoTrendH.IsUpTrend -> " + trend.IsUpTrend);
			}
			
			
			
				
			if(DateTime.Now.CompareTo(new DateTime(2015,3,30)) < 0)
			SetLowAndHigh();
			
        }
		
		private void SetLowAndHigh(){
			_numLow = Low[Period];
			_numHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(_numLow < Low[bar]){
					_numLow = Low[bar];
				}
				if(_numHigh > High[bar]){
					_numHigh = High[bar];
				}
			}
		}
		
		
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
				_price = e.Price;
								
				ChangeOnPriceUpdate(_price);
			}
			
				
		}
		
		
		private void ChangeOnPriceUpdate(double price){

			BuyOrSell(price);
			
		}
		

		
		
		private void BuyOrSell(double price){

			//Print("IsLongTrend -> " + IsLongTrend);
			
			if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat && isFoundTrend){
				isFirstTickTrendInOrder = true;
				atmStrategyId = GetAtmStrategyUniqueId();
				orderId = GetAtmStrategyUniqueId();
				if(!IsLongTrend){
					if(price > _numLow && GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){// upper then green line
						//if(GetAtmStrategyMarketPosition(atmStrategyId) != MarketPosition.Flat){
						//	Print ("HAVE ANY ORDER");
						//}
						//else 
						if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
							//atmStrategyId = GetAtmStrategyUniqueId();
							//orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Sell, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							startOrderPrice = price;
							openedOrderId = orderId;
						}
					}
				}
				else 
				if(IsLongTrend){
					if(price < _numHigh && GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
						//if(GetAtmStrategyMarketPosition(atmStrategyId) != MarketPosition.Flat){
						//	Print ("HAVE ANY ORDER");
						//}
						//else 
						if(GetAtmStrategyMarketPosition(atmStrategyId) == MarketPosition.Flat){
							//atmStrategyId = GetAtmStrategyUniqueId();
							//orderId = GetAtmStrategyUniqueId();
							AtmStrategyCreate(OrderAction.Buy, OrderType.Market, 0, 0, TimeInForce.Day, orderId, "AqueGenNinjaStrategy", atmStrategyId);
							startOrderPrice = price;
							openedOrderId = orderId;
						}
					}
				}
			}
			
			else{
				if(isFirstTickTrendInOrder){
					isFirstTickTrendInOrder = false;
					isLongTrendFirstTickInOrder = IsLongTrend;
				}
				else{
					if(isLongTrendFirstTickInOrder != IsLongTrend && startOrderPrice > (price + (closeOrderAfterChangeTrendOnTick * TickSize))){
					//	AtmStrategyChangeStopTarget(0, 1 * TickSize, openedOrderId," ");
						AtmStrategyClose(atmStrategyId);//тут закоментировать если будет косяково выходить с ордера
					}
				}
			
			}
			
		}
		
		private double GetLowBar(int timeFrameMinute, int upTrendBarsAgo){
			double lowBarValue = 10000000;
			for(int i = 0; i < timeFrameMinute; i++){
				if((Low[CurrentBar] - i) < lowBarValue){
					lowBarValue = Low[CurrentBar] - i;
				}
			}
			return lowBarValue;
		}
		
		
		
		private bool GetTrend(){
		
			int upTrendOccurence 		= 1;	int upTrendStartBarsAgo		= 0;	int upTrendEndBarsAgo 		= 0;
			int downTrendOccurence 		= 1;	int	downTrendStartBarsAgo	= 0;	int	downTrendEndBarsAgo 	= 0;
		
			if(((DrawObjects["UpTrendRay"] ==null) || (DrawObjects["UpTrendRay"].Locked)) 
				&& ((DrawObjects["DownTrendRay"] ==null) || (DrawObjects["DownTrendRay"].Locked))) {
				// Calculate up trend line
				upTrendOccurence 		= 1;	
				while (GetLowBar(5, upTrendEndBarsAgo) <= GetLowBar(5, upTrendStartBarsAgo))
				{	upTrendStartBarsAgo 	= Swing(strength).SwingLowBar(0, upTrendOccurence + 1, CurrentBar);
					upTrendEndBarsAgo 	= Swing(strength).SwingLowBar(0, upTrendOccurence, CurrentBar);
					if (upTrendStartBarsAgo < 0 || upTrendEndBarsAgo < 0)
						break;
					upTrendOccurence++;
				}
				// Calculate down trend line	
				downTrendOccurence 		= 1;
				while (High[downTrendEndBarsAgo] >= High[downTrendStartBarsAgo])
				{	downTrendStartBarsAgo 		= Swing(strength).SwingHighBar(0, downTrendOccurence + 1, CurrentBar);
					downTrendEndBarsAgo 		= Swing(strength).SwingHighBar(0, downTrendOccurence, CurrentBar);
					if (downTrendStartBarsAgo < 0 || downTrendEndBarsAgo < 0)
						break;
					downTrendOccurence++;
				}
		 	}	
			
			if (upTrendStartBarsAgo > 0 && upTrendEndBarsAgo > 0 && upTrendStartBarsAgo < downTrendStartBarsAgo)
			{	
				if ( (DrawObjects["UpTrendRay"] !=null) && (!DrawObjects["UpTrendRay"].Locked) )
				{	IRay upTrendRay		= (IRay) DrawObjects["UpTrendRay"];	
					upTrendStartBarsAgo = upTrendRay.Anchor1BarsAgo;
					upTrendEndBarsAgo   = upTrendRay.Anchor2BarsAgo;
				}
				Print("Now LONG Trend Line");
				return true;
			}


			else 
			if (downTrendStartBarsAgo > 0 && downTrendEndBarsAgo > 0  && upTrendStartBarsAgo > downTrendStartBarsAgo)
			{	
				if ( (DrawObjects["DownTrendRay"] !=null) && (!DrawObjects["DownTrendRay"].Locked) )
				{	IRay downTrendRay	= (IRay) DrawObjects["DownTrendRay"];	
					downTrendStartBarsAgo = downTrendRay.Anchor1BarsAgo;
					downTrendEndBarsAgo   = downTrendRay.Anchor2BarsAgo;
				}
				Print("Now DOWN Trend Line");
				return false;
			}
			
			return IsLongTrend;
		}
		
		#region Indicator Get\Set

		
		[Description("Number of bars required on each side swing pivot points used to connect the trend lines")]
        [Category("Parameters")]
        public int Strength
        {
            get { return strength; }
            set { strength = Math.Max(1, value); }
        }

		
        #endregion
		
        #region Properties		
		[Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set { _period = Math.Max(1, value); }
        }
	

       
		
		//[Description("")]
        //[GridCategory("Parameters")]
        private bool IsLongTrend
        {
            get { return _isLongTrend; }
            set { _isLongTrend = value; }
        }
		
		[Description("closeOrderAfterChangeTrendOnTick")]
        [GridCategory("Parameters")]
        public int CloseOrderAfterChangeTrendOnTick
        {
            get { return closeOrderAfterChangeTrendOnTick; }
            set { closeOrderAfterChangeTrendOnTick = Math.Max(1, value); }
        }
		
		[Description("currentTimeBars")]
        [GridCategory("Parameters")]
        public int CurrentTimeBars
        {
            get { return currentTimeBars; }
            set { currentTimeBars = Math.Max(1, value); }
        }
		
		[Description("trendTimeBars")]
        [GridCategory("Parameters")]
        public int TrendTimeBars
        {
            get { return trendTimeBars; }
            set { trendTimeBars = Math.Max(1, value); }
        }
		
		
        #endregion
    }
}
