#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSReversBarCCI : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType = OrderType.FLAT;
		private bool isBreakevenEnable = false;
		private bool isCanEnterOrder = false;
		

		private double stopLossPrice = 0;
		private double trailStopLossPrice = 0;
		
		private bool isTrailStopEnable = false;
		
		
		private double previousCCI = 0;
		private double currentCCI = 0;
		
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
        }
		
		protected override void OnTermination()
		{
			ExitShort("Order");
			ExitLong("Order");
		}


        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			
			if (Historical == true)
			{
				return;
			}
			
			IDataSeries cciDataSeries = Close;
				
			switch (CCIInputSeries)
            {
                case InputSeries.CLOSE:
                    cciDataSeries = Close;
                    break;
                case InputSeries.HIGH:
                    cciDataSeries = High;
                    break;
                case InputSeries.LOW:
                    cciDataSeries = Low;
                    break;
                case InputSeries.MEDIAN:
                    cciDataSeries = Median;
                    break;
                case InputSeries.OPEN:
                    cciDataSeries = Open;
                    break;
                case InputSeries.TYPICAL:
                    cciDataSeries = Typical;
                    break;
                case InputSeries.WEIGHTED:
                    cciDataSeries = Weighted;
                    break;
            }

			previousCCI = currentCCI;
			currentCCI = CCI(cciDataSeries, PeriodCCI)[0]; 
			

			if (previousCCI < 0 && currentCCI > 0)
			{
				SetStopLoss("Order", CalculationMode.Ticks, StopLoss, false);
				
				if(orderType == OrderType.SELL || orderType == OrderType.FLAT)
				{
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					isTrailStopEnable = false;
					Print("---------------");
					Print("Can Enter Order BUY");
				}
				else if(orderType == OrderType.BUY)
				{
					isCanEnterOrder = false;
					return;
				}
				Print("EMA buy");
				orderType = OrderType.BUY;
			}
			else if (previousCCI > 0 && currentCCI < 0)
			{	
				SetStopLoss("Order", CalculationMode.Ticks, StopLoss, false);
				
				if(orderType == OrderType.BUY || orderType == OrderType.FLAT)
				{
					isCanEnterOrder = true;
					isBreakevenEnable = false;
					isTrailStopEnable = false;
					Print("---------------");
					Print("Can Enter Order SELL");
				}
				else if(orderType == OrderType.SELL)
				{
					isCanEnterOrder = false;
					return;
				}
				Print("EMA sell");
				orderType = OrderType.SELL;
			}

        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) 
			{
				double price = e.Price;
				if(isCanEnterOrder && orderType == OrderType.SELL)
				{
					isCanEnterOrder = false;
					startOrderPrice = price;
					trailStopLossPrice = startOrderPrice;
					Print("Sell startOrderPrice -> " + startOrderPrice);
					EnterShort("Order");
				}
				else if(isCanEnterOrder && orderType == OrderType.BUY)
				{
					isCanEnterOrder = false;
					startOrderPrice = price;
					trailStopLossPrice = startOrderPrice;
					Print("Buy startOrderPrice -> " + startOrderPrice);
					EnterLong("Order");
				}
				
				
				if (Position.MarketPosition != MarketPosition.Flat)
				{
					if(BreakevenSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY)
						{
							if(startOrderPrice + Breakeven * TickSize <= price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice + BreakevenPosition * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("BuyStopLossBreakeven -> " + (startOrderPrice + BreakevenPosition * TickSize));
								Print("price -> " + price);
							}
						}
						else if(orderType == OrderType.SELL)
						{
							if(startOrderPrice - Breakeven * TickSize >= price && !isBreakevenEnable)
							{
								stopLossPrice = startOrderPrice - BreakevenPosition * TickSize;
								SetStopLoss("Order", CalculationMode.Price, stopLossPrice, false);
								isBreakevenEnable = true;
								Print("SellStopLossBreakeven -> " + (startOrderPrice - BreakevenPosition * TickSize));
								Print("price -> " + price);
							}
						}
					}
					if(TrailStopSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY && startOrderPrice + ProfitTrigger * TickSize <= price)
						{
							if(!isTrailStopEnable)
							{
								Print("Trail ON");
								isTrailStopEnable = true;
								trailStopLossPrice = price - TrailStop * TickSize;
								Print("Buy Change TrailStop " + trailStopLossPrice);
								Print("price -> " + price);
							}
							
							if(trailStopLossPrice + TrailStop * TickSize+ Frequency * TickSize <= price && isTrailStopEnable)
							{
								trailStopLossPrice = price - TrailStop * TickSize;
								SetStopLoss("Order", CalculationMode.Price, trailStopLossPrice, false);
								Print("Buy Change TrailStop " + trailStopLossPrice);
								Print("price -> " + price);
							}
						}
						else if(orderType == OrderType.SELL && startOrderPrice - ProfitTrigger * TickSize >= price)
						{
							if(!isTrailStopEnable)
							{
								Print("Trail ON");
								isTrailStopEnable = true;
								trailStopLossPrice = price + TrailStop * TickSize;
								Print("Sell Change TrailStop " + trailStopLossPrice);
								Print("price -> " + price);
							}
							
							if(trailStopLossPrice - TrailStop * TickSize - Frequency * TickSize >= price && isTrailStopEnable)
							{
								trailStopLossPrice = price + TrailStop * TickSize;
								SetStopLoss("Order", CalculationMode.Price, trailStopLossPrice, false);
								Print("Sell Change TrailStop " + trailStopLossPrice);
								Print("price -> " + price);
							}
						}
					}
				}
			}
		}
	
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL,
			FLAT
		}
		
		public enum InputSeries
		{
			CLOSE,
			HIGH,
			LOW,
			MEDIAN,
			OPEN,
			TYPICAL,
			WEIGHTED
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[GridCategory("Order")]
		public Switch BreakevenSwitch
		{get; set;}
		
		[Description("Цена безубытка, в тиках")]
		[GridCategory("Order")]
		public int BreakevenPosition
		{get; set;}
		
		[Description("Перенос стоп-лосса в безубыток, в тиках")]
		[GridCategory("Order")]
		public int Breakeven
		{get; set;}
		
		[Description("")]
		[GridCategory("Order")]
		public int StopLoss
		{get; set;}
		
		[Description("")]
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[Description("Включить трейлинг через, в тиках")]
		[GridCategory("TrailStop")]
		public int ProfitTrigger
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int TrailStop
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public Switch TrailStopSwitch
		{get; set;}
		
		[Description("Как часто подтягивать стоп-лосс за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int Frequency
		{get; set;}
		
        [Description("")]
        [GridCategory("CCI")]
        public int PeriodCCI
        {
            get { return fast; }
            set { fast = Math.Max(1, value); }
        }

		[GridCategory("CCI")]
		public InputSeries CCIInputSeries
		{get; set;}
		

    }
}
