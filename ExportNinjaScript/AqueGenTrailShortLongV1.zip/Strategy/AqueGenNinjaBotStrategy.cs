#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AqueGenNinjaBotStrategy : Strategy
    {
        //#region Variables
        // Wizard generated variables
        private int myInput0 = 1; // Default setting for MyInput0
		
		private double _numLow = 0;
		private double _numHigh = 0;
		
		private int _newPeriod = 0;
		

		
		private double _price = 0.0;
		

		
		private double _orderStartPrice = 0.0;
		private bool _isOrderPresent = false;
		private bool _isPlusOrder = false;
		private bool _isLongBar = false;
		
		
		private double _currentStopLossPriceShort = 100000.0;
		private double _currentStopLossPriceLong = 0.0;
		private double _lastPriceShort = 100000.0;
		private double _lastPriceLong = 0.0;
		
		private double _stopLossPrice = 0.0;
		private bool _isChangeStopLoss = false;
		private bool _isChangePrice = false;
		
		
		private double _stopLossTicks = 5.0;
		private double _changeStopLossAfterTicks = 5.0;
		private int _period = 20;
		private int _barsBetweenOrder = 0;
		private bool _isLongTrend = true;
		
		private double _changeStopLossInPlusOrderAfterTicks = 5;
		private double _stopLossPositionAfterPlussedChange = 2;
		

		
        // User defined variables (add any user defined variables below)
        //#endregion

		

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
			
			//SetProfitTarget("", CalculationMode.Ticks, _stopLossTicks + 5);
            //SetTrailStop("", CalculationMode.Ticks, _stopLossTicks, false);
			//SetStopLoss(CalculationMode.Ticks, _stopLossTicks);
            CalculateOnBarClose = true;
					

        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
		
        protected override void OnBarUpdate()
        {	
			if(DateTime.Now.CompareTo(new DateTime(2015,3,15)) < 0)
			SetLowAndHigh();
        }
		
		private void SetLowAndHigh(){
			_numLow = Low[Period];
			_numHigh = High[Period];
			for(int bar = 0; bar < Period - 1; bar++){
				if(_numLow < Low[bar]){
					_numLow = Low[bar];
				}
				if(_numHigh > High[bar]){
					_numHigh = High[bar];
				}
			}
		}
		
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				SetStopLoss(CalculationMode.Ticks, _stopLossTicks);
				_currentStopLossPriceShort = 100000.0;
				_lastPriceShort = 100000.0;
				_orderStartPrice = 0.0;
				_isOrderPresent = false;
				_isPlusOrder = false;
				
				_isChangeStopLoss = false;
				_isChangePrice = false;
				
				_currentStopLossPriceLong = 0.0;
				_lastPriceLong = 0.0;
				Print("Default value");
			}
			
			// Print some data to the Output window
			if (e.MarketDataType == MarketDataType.Last) {

				_price = e.Price;
				
				if(_lastPriceShort > _price && !IsLongTrend){
					_lastPriceShort = _price;
					_isChangePrice = true;
				}
				else if(_lastPriceLong < _price && IsLongTrend){
					_lastPriceLong = _price;
					_isChangePrice = true;
				}
				else{
					_isChangePrice = false;
				}
				
			}
			
			ChangeOnPriceUpdate(_price);	
		}
		
		
		private void ChangeOnPriceUpdate(double price){

			if(_price >= Close[0])
				_isLongBar = true;
			else
				_isLongBar = false;
			
			BuyOrSell(price, _isLongBar);
			
			
		}
		

		
		
		private void BuyOrSell(double price, bool isLongBar){
			if(!IsLongTrend){		
				if(price > _numLow && _isOrderPresent == false){// upper then green line
					EnterShort(1,"EnterShort");
					Print("EnterShort -> " + price);
					if(_isOrderPresent == false){
						_isOrderPresent = true;
						_orderStartPrice = price;
					}
					SetStopLoss(CalculationMode.Ticks, _changeStopLossAfterTicks);
				}
				else if(price <= _numLow && _isOrderPresent){ //down then green line
					_stopLossPrice = price + (_stopLossTicks * TickSize);
					if(_currentStopLossPriceShort > _stopLossPrice){
						_currentStopLossPriceShort = _stopLossPrice;
						_isChangeStopLoss = true;
					}
					else{
						_isChangeStopLoss = false;
					}

					if(_isChangePrice && _isChangeStopLoss){
						if(_orderStartPrice - _changeStopLossInPlusOrderAfterTicks * TickSize >= price && _isPlusOrder == false){
							_currentStopLossPriceShort = price + (_stopLossPositionAfterPlussedChange * TickSize);
							SetStopLoss(CalculationMode.Price, _currentStopLossPriceShort);
							_isPlusOrder = true;
						}
						else{
							if(_isPlusOrder){
								SetStopLoss(CalculationMode.Price, _currentStopLossPriceShort);
							}
						}
					}
				}
				//else if(price < _numHigh){
					//ExitShort("EnterShort");
				//}
			}
			
			else {
				if(price < _numHigh && _isOrderPresent == false){
					EnterLong(1, "EnterLong");
					Print("EnterLong -> " + price);
					
					if(_isOrderPresent == false){
						_isOrderPresent = true;
						_orderStartPrice = price;
					}
					SetStopLoss(CalculationMode.Ticks, _changeStopLossAfterTicks);
				}
				else if(price >= _numHigh && _isOrderPresent){
					_stopLossPrice = price - (_stopLossTicks * TickSize);
					if(_currentStopLossPriceLong < _stopLossPrice){
						_currentStopLossPriceLong = _stopLossPrice;
						_isChangeStopLoss = true;
					}
					else{
						_isChangeStopLoss = false;
					}

					if(_isChangePrice && _isChangeStopLoss){
						if(_orderStartPrice + _changeStopLossInPlusOrderAfterTicks * TickSize <= price && _isPlusOrder == false){
							_currentStopLossPriceLong = price - (_stopLossPositionAfterPlussedChange * TickSize);
							SetStopLoss(CalculationMode.Price, _currentStopLossPriceLong);
							_isPlusOrder = true;
						}
						else{
							if(_isPlusOrder){
								SetStopLoss(CalculationMode.Price, _currentStopLossPriceLong);
							}
						}
					}
					
				}
				//else if(price > _numLow){
					//ExitLong("EnterLong");
				//}
				
				
			}
			
		}
		

		
        #region Properties		
		[Description("Number of bars used  for calculations")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return _period; }
            set { _period = Math.Max(1, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public int BarsBetweenOrder
        {
            get { return _barsBetweenOrder; }
            set { _barsBetweenOrder = Math.Max(1, value); }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public double StopLossTicks
        {
            get { return _stopLossTicks; }
            set { _stopLossTicks = Math.Max(0, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public double ChangeStopLossAfterTicks
        {
            get { return _changeStopLossAfterTicks; }
            set { _changeStopLossAfterTicks = Math.Max(0, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public double ChangeStopLossInPlusOrderAfterTicks
        {
            get { return _changeStopLossInPlusOrderAfterTicks; }
            set { _changeStopLossInPlusOrderAfterTicks = Math.Max(0, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public double StopLossPositionAfterPlussedChange
        {
            get { return _stopLossPositionAfterPlussedChange; }
            set { _stopLossPositionAfterPlussedChange = Math.Max(0, value); }
        }
		
		[Description("")]
        [GridCategory("Parameters")]
        public bool IsLongTrend
        {
            get { return _isLongTrend; }
            set { _isLongTrend = value; }
        }
		
        #endregion
    }
}
