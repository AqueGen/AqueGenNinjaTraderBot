#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSReversBarEMA : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		private double startOrderPrice = 0;
		private OrderType orderType;
		
		private bool isStartOrderPriceFound = false;
		private bool isCanEnterOrder = false;
		

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}
			

			if (CrossAbove(EMA(Fast), EMA(Slow), 1))
			{
				SetStopLoss("Order", CalculationMode.Price, Int32.MinValue, false);
				
				orderType = OrderType.BUY;
			   // EnterLong("Order");
				isCanEnterOrder = true;
				
				if(ProfitTargetSwitch == Switch.ON)
				{
					SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
				}
			}
			else if (CrossBelow(EMA(Fast), EMA(Slow), 1))
			{
				SetStopLoss("Order", CalculationMode.Price, Int32.MaxValue, false);
				
				orderType = OrderType.SELL;
			    //EnterShort("Order");
				isCanEnterOrder = true;
				
				if(ProfitTargetSwitch == Switch.ON)
				{
					SetProfitTarget("Order", CalculationMode.Ticks, ProfitTarget);
				}
			}
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) {
			
				if(isCanEnterOrder && orderType == OrderType.SELL)
				{
					isCanEnterOrder = false;
					startOrderPrice = e.Price;
					Print("startOrderPrice -> " + startOrderPrice);
					EnterShort("Order");
				}
				else if(isCanEnterOrder && orderType == OrderType.BUY)
				{
					isCanEnterOrder = false;
					startOrderPrice = e.Price;
					EnterLong("Order");
				}
				
				if (Position.MarketPosition != MarketPosition.Flat)
				{
					
					if(BreakevenSwitch == Switch.ON)
					{
						if(orderType == OrderType.BUY)
						{
							if(startOrderPrice + BreakevenTicks * TickSize <= e.Price)
							{
								SetStopLoss("Order", CalculationMode.Price, startOrderPrice + 2 * TickSize, false);
								Print("startOrderPrice -> " + startOrderPrice);
								Print("BuyStopLossBreakeven -> " + (startOrderPrice + 2 * TickSize));
							}
						}
						else if(orderType == OrderType.SELL)
						{
							if(startOrderPrice - BreakevenTicks * TickSize >= e.Price)
							{
								SetStopLoss("Order", CalculationMode.Price, startOrderPrice + 2 * TickSize, false);
								Print("startOrderPrice -> " + startOrderPrice);
								Print("SellStopLossBreakeven -> " + (startOrderPrice + 2 * TickSize));
							}
						}
					}
				}
			}
		}
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[GridCategory("Order")]
		public Switch BreakevenSwitch
		{get; set;}

		[GridCategory("Order")]
		public int BreakevenTicks
		{get; set;}
		
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[GridCategory("Order")]
		public Switch ProfitTargetSwitch
		{get; set;}
		
        [Description("")]
        [GridCategory("Parameters")]
        public int Fast
        {
            get { return fast; }
            set { fast = Math.Max(1, value); }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public int Slow
        {
            get { return slow; }
            set { slow = Math.Max(1, value); }
        }

    }
}
