#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class AGNSUnirenkoLimits : Strategy
    {

        private int fast = 1; // Default setting for Fast
        private int slow = 1; // Default setting for Slow

		
		private OrderType orderType = OrderType.FLAT;
		
		
		private double stopLossPrice = 0;
		private double trailStopLossPrice = 0;
		
		private bool isTrailStopEnable = false;
		
		
		private int orderEnterBar = 0;
		
		private Bar previousBar = null;
		private Bar currentBar = null;
		
		
		private double startOrderPrice = 0;
		private OrderType startOrderType = OrderType.FLAT;
		
		private int usedOrders = 0;
		
		private bool isStopLimitOrder = false;
		private IOrder myEntryOrder = null;

		private double Price;
		
		private double maxPriceAfterEnter = 0;
		private bool isCanEnterReversOrder = false;
		private bool isCanEnterTrailStop = false;
		

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			
			SetStopLoss(CalculationMode.Ticks, StopLoss);
			SetProfitTarget(CalculationMode.Ticks, ProfitTarget);
        }

		protected override void OnTermination()
		{

		}
		
		protected override void OnStartUp()
		{
			//BuyOrder = new EnteredOrder();
			//SellOrder = new EnteredOrder();
			
			previousBar = new Bar
			{
				High = High[1],
				Low = Low[1]
			};
			currentBar = new Bar
			{
				High = High[0],
				Low = Low[0]
			};
		}
		
        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Historical == true && History == Switch.OFF)
			{
				return;
			}	
			if (Historical == true)
			{
				return;
			}	
			
			
			previousBar = currentBar;
			currentBar = new Bar
			{
				High = High[0],
				Low = Low[0]
			};

			
			double min = currentBar.Diapasone - TickSize - TickSize/5;
			double max = currentBar.Diapasone - TickSize + TickSize/5;
			double openOffsetTickPrice = OpenOffset * TickSize;
			
			if(openOffsetTickPrice > max || openOffsetTickPrice < min)
			{
				Print("-> " + openOffsetTickPrice);
				Print("min -> " + min);
				Print("max -> " + max);
				
				if(myEntryOrder != null)
				{
					CancelOrder(myEntryOrder);
					Print("Limit Order deleted");
				}
				
				return;
			}

			usedOrders = 0;
			
			Print("================");
			if(Position.MarketPosition == MarketPosition.Flat)
			{			
				if(previousBar.Low > currentBar.Low/* && previousBar.High > currentBar.High*/)
				{
					if(Price < currentBar.High + 1 * TickSize)
					{
						SetStopLoss(CalculationMode.Ticks, StopLoss);
						Print("----------");
						Print(Time[0]);
						Print("Price " + Price);
						Print("Enter Long Limit " + (currentBar.High + 1 * TickSize));
						myEntryOrder = EnterLongStopLimit(currentBar.High + 1 * TickSize, currentBar.High + 1 * TickSize);
						Print("Enter Long Stop " + (currentBar.High + 1 * TickSize));
						orderType = OrderType.BUY;
						isStopLimitOrder = true;
					}
				}
				else if(/*previousBar.Low < currentBar.Low &&*/ previousBar.High < currentBar.High)
				{
					if(Price > currentBar.Low - 1 * TickSize)
					{
						SetStopLoss(CalculationMode.Ticks, StopLoss);
						Print("----------");
						Print(Time[0]);
						Print("Price " + Price);
						Print("Enter Short Limit " + (currentBar.Low - 1 * TickSize));
						myEntryOrder = EnterShortStopLimit(currentBar.Low - 1 * TickSize, currentBar.Low - 1 * TickSize);
						Print("Enter Short Stop " + (currentBar.Low - 1 * TickSize));
						orderType = OrderType.SELL;
						isStopLimitOrder = true;
						
					}
				}
			}
        }
		
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType == MarketDataType.Last) 
			{
				Price = e.Price;
				
				
				if(Position.MarketPosition != MarketPosition.Flat)
				{
					if(startOrderType == OrderType.BUY)
					{
						if(startOrderPrice < Price && maxPriceAfterEnter < Price)
						{
							maxPriceAfterEnter =  Price;
						}
						
						if(startOrderPrice + 5 * TickSize < maxPriceAfterEnter)
						{
							isCanEnterReversOrder = false;
							isCanEnterTrailStop = true;
						}
						else
						{
							isCanEnterReversOrder = true;
							isCanEnterTrailStop = false;
						}
					}
					else if(startOrderType == OrderType.SELL)
					{
						if(startOrderPrice > Price && maxPriceAfterEnter > Price)
						{
							maxPriceAfterEnter =  Price;
						}
						
						if(startOrderPrice - 5 * TickSize > maxPriceAfterEnter)
						{
							isCanEnterReversOrder = false;
							isCanEnterTrailStop = true;
						}
						else
						{
							isCanEnterReversOrder = true;
							isCanEnterTrailStop = false;
						}
					}
				}
				

				if(Position.MarketPosition == MarketPosition.Short)
				{
					if(usedOrders < 2)
					{
						if(isStopLimitOrder)
						{
							isStopLimitOrder = false;
							startOrderPrice = Price;
							trailStopLossPrice = startOrderPrice;
							maxPriceAfterEnter = startOrderPrice;
							startOrderType = OrderType.SELL;
							orderEnterBar = CurrentBar;
							isTrailStopEnable = false;
							Print("EnterShortStopLimit");
							Print("Price " + Price);
							Print("startOrderPrice " + startOrderPrice);
							usedOrders++;
						}
						
						if(ReversOrderSwitch == Switch.ON && isCanEnterReversOrder)
						{
							//if(currentBar.High + 1 * TickSize < Price && orderEnterBar != CurrentBar || currentBar.Low - 1 * TickSize + TickInDiapasone * TickSize < Price && orderEnterBar == CurrentBar)
							if(currentBar.Low - 1 * TickSize + TickInDiapasone * TickSize < Price && orderEnterBar == CurrentBar)
							{
								SetStopLoss(CalculationMode.Ticks, StopLoss);
								Print("EnterLong");
								Print(Time[0]);
								Print("Price " + Price);
								
								EnterLong();
								
								startOrderPrice = Price;
								trailStopLossPrice = startOrderPrice;
								maxPriceAfterEnter = startOrderPrice;
								startOrderType = OrderType.BUY;
								orderEnterBar = CurrentBar;
								isTrailStopEnable = false;
								usedOrders++;
							}
						}
					}
				}
				else if(Position.MarketPosition == MarketPosition.Long)
				{
					if(usedOrders < 2)
					{
						if(isStopLimitOrder)
						{
							isStopLimitOrder = false;
							startOrderPrice = Price;
							trailStopLossPrice = startOrderPrice;
							maxPriceAfterEnter = startOrderPrice;
							startOrderType = OrderType.BUY;
							orderEnterBar = CurrentBar;
							isTrailStopEnable = false;
							Print("EnterLongStopLimit");
							Print("Price " + Price);
							Print("startOrderPrice " + startOrderPrice);
							usedOrders++;
						}
						
						if(ReversOrderSwitch == Switch.ON && isCanEnterReversOrder)
						{
							//if(currentBar.Low - 1 * TickSize > Price && orderEnterBar != CurrentBar || currentBar.High + 1 * TickSize - TickInDiapasone * TickSize > Price && orderEnterBar == CurrentBar)
							if(currentBar.High + 1 * TickSize - TickInDiapasone * TickSize > Price && orderEnterBar == CurrentBar)
							{
								SetStopLoss(CalculationMode.Ticks, StopLoss);
								
								Print("EnterShort");
								Print(Time[0]);
								Print("Price " + Price);
								
								EnterShort();
								
								startOrderPrice = Price;
								trailStopLossPrice = startOrderPrice;
								maxPriceAfterEnter = startOrderPrice;
								startOrderType = OrderType.SELL;
								orderEnterBar = CurrentBar;
								isTrailStopEnable = false;
								usedOrders++;
							}
						}
					}
				}
				
				
				if(isCanEnterTrailStop)
				{
					if(TrailStopSwitch == Switch.ON)
					{
						if(Position.MarketPosition == MarketPosition.Long)
						{
							if(startOrderType == OrderType.BUY && startOrderPrice + ProfitTrigger * TickSize <= Price)
							{
								if(!isTrailStopEnable)
								{
									Print("Trail ON");
									isTrailStopEnable = true;
									trailStopLossPrice = Price - TrailStop * TickSize;
									Print("Buy startOrderPrice " + startOrderPrice);
									Print("Buy Change TrailStop " + trailStopLossPrice);
									Print("price -> " + Price);
								}
								
								if(trailStopLossPrice + TrailStop * TickSize+ Frequency * TickSize <= Price && isTrailStopEnable)
								{
									trailStopLossPrice = Price - TrailStop * TickSize;
									Print("Buy Change TrailStop " + trailStopLossPrice);
									SetStopLoss(CalculationMode.Price, trailStopLossPrice);
									Print("price -> " + Price);
								}
							}
						}
						if(Position.MarketPosition == MarketPosition.Short)
						{
							if(startOrderType == OrderType.SELL && startOrderPrice - ProfitTrigger * TickSize >= Price)
							{
								if(!isTrailStopEnable)
								{
									Print("Trail ON");
									isTrailStopEnable = true;
									trailStopLossPrice = Price + TrailStop * TickSize;
									Print("Sell startOrderPrice " + startOrderPrice);
									Print("Sell Change TrailStop " + trailStopLossPrice);
									Print("price -> " + Price);
								}
								
								if(trailStopLossPrice - TrailStop * TickSize - Frequency * TickSize >= Price && isTrailStopEnable)
								{
									trailStopLossPrice = Price + TrailStop * TickSize;
									Print("Sell Change TrailStop " + trailStopLossPrice);
									SetStopLoss(CalculationMode.Price, trailStopLossPrice);
									Print("price -> " + Price);
								}
							}
						}
					}
				}
			}
		}
	
		public class Bar
		{
			public double High {get; set;}
			public double Low {get; set;}
			public double Diapasone
			{
				get
				{
					return High - Low;
				}
			}
			
			public override string  ToString()
			{
				return string.Format("Bar-> High: {0}, Low: {1}", High, Low);
			}
		}
		
		public class EnteredOrder
		{
			public OrderType Type {get; set;}
			public int IndexBar {get; set;}
		}
		
		
		
		
		public enum Switch
		{
			ON,
			OFF
		}
		
		public enum OrderType
		{
			BUY,
			SELL,
			FLAT
		}
		
		public enum InputSeries
		{
			CLOSE,
			HIGH,
			LOW,
			MEDIAN,
			OPEN,
			TYPICAL,
			WEIGHTED
		}
		
		
		[GridCategory("History")]
		public Switch History
		{get; set;}
		
		
		[Description("")]
		[GridCategory("Order")]
		public int StopLoss
		{get; set;}
		
		[Description("")]
		[GridCategory("Order")]
		public int ProfitTarget
		{get; set;}
		
		[Description("Включить трейлинг через, в тиках")]
		[GridCategory("TrailStop")]
		public int ProfitTrigger
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int TrailStop
		{get; set;}
		
		[Description("Расположение стоп-лосса за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public Switch TrailStopSwitch
		{get; set;}
		
		[Description("Как часто подтягивать стоп-лосс за ценой, в тиках")]
		[GridCategory("TrailStop")]
		public int Frequency
		{get; set;}
		
		[Description("")]
		[GridCategory("EnterOrder")]
		public int TickInDiapasone
		{get; set;}
		
		[Description("")]
		[GridCategory("EnterOrder")]
		public Switch ReversOrderSwitch
		{get; set;}
		
		
		
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int OpenOffset
		{get; set;}
		/*
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int TickTrend
		{get; set;}
		
		[Description("")]
		[GridCategory("DataSeriesChart")]
		public int TickReversal
		{get; set;}
		*/



    }
}
